import { create } from "zustand";
import { getCardById, getDeckIds, loadStoredCustomDeck, setCustomDeck } from "./content";
import { fisherYatesShuffle } from "./shuffle";
import {
  ALL_LEVELS,
  DEFAULT_THRESHOLDS,
  SAVE_KEY,
  SAVE_VERSION,
  deckKey,
  type GameCard,
  type Gender,
  type LevelId,
  type Mode,
  type Player,
  type Screen,
} from "./types";

export interface SavedState {
  version: number;
  screen: Screen;
  players: [Player, Player];
  currentPlayerIndex: 0 | 1;
  unlockThresholds: number[];
  selectedLevel: LevelId;
  mode: Mode;
  decks: Record<string, string[]>;
  currentCardId: string | null;
  ageConfirmed: boolean;
  heatStart: boolean;
  bdsmOn: boolean;
}

interface GameStore {
  hydrated: boolean;
  screen: Screen;
  players: [Player, Player];
  currentPlayerIndex: 0 | 1;
  unlockThresholds: number[];
  selectedLevel: LevelId;
  mode: Mode;
  decks: Record<string, string[]>;
  currentCard: GameCard | null;
  deckEmpty: boolean;
  ageConfirmed: boolean;
  justUnlocked: LevelId | null;
  heatStart: boolean;
  bdsmOn: boolean;
  /** Bumps whenever the active deck (built-in or imported) changes, so views can refresh. */
  deckRevision: number;
  hydrate: () => void;
  /** Activates an imported deck (null = built-in). Resets drawn piles. Returns false if it could not be saved. */
  applyDeck: (cards: GameCard[] | null) => boolean;
  confirmAge: () => void;
  goToSetup: () => void;
  setScreen: (screen: Screen) => void;
  setPlayerName: (index: 0 | 1, name: string) => void;
  setPlayerGender: (index: 0 | 1, gender: Gender) => void;
  setThreshold: (levelFrom2: number, value: number) => void;
  setThresholds: (values: number[]) => void;
  startPlaying: () => void;
  selectMode: (mode: Mode) => void;
  selectLevel: (level: LevelId) => void;
  drawCard: () => void;
  reshuffleCurrent: () => void;
  drink: (index: 0 | 1) => void;
  completeCard: () => void;
  skipWithDrink: () => void;
  nextWithoutDrink: () => void;
  resetGame: () => void;
  dismissUnlock: () => void;
  resumePlaying: () => void;
  goHome: () => void;
  setHeatStart: (value: boolean) => void;
  setBdsmOn: (value: boolean) => void;
}

const defaultPlayers = (): [Player, Player] => [
  { name: "เค้า", gender: "male", drinks: 0 },
  { name: "เธอ", gender: "female", drinks: 0 },
];

function totalDrinksOf(players: [Player, Player]): number {
  return players[0].drinks + players[1].drinks;
}

export function isLevelUnlocked(
  level: LevelId,
  totalDrinks: number,
  thresholds: number[],
): boolean {
  if (level === 1) return true;
  const need = thresholds[level - 2] ?? DEFAULT_THRESHOLDS[level - 2];
  return totalDrinks >= (need ?? 0);
}

export function drinksToUnlock(level: LevelId, totalDrinks: number, thresholds: number[]): number {
  if (level === 1) return 0;
  const need = thresholds[level - 2] ?? DEFAULT_THRESHOLDS[level - 2] ?? 0;
  return Math.max(0, need - totalDrinks);
}

function persist(partial: Omit<SavedState, "version">) {
  try {
    const payload: SavedState = { version: SAVE_VERSION, ...partial };
    localStorage.setItem(SAVE_KEY, JSON.stringify(payload));
  } catch {
    /* private mode / quota — keep playing in memory */
  }
}

function snapshot(s: GameStore): Omit<SavedState, "version"> {
  return {
    screen: s.screen,
    players: s.players,
    currentPlayerIndex: s.currentPlayerIndex,
    unlockThresholds: s.unlockThresholds,
    selectedLevel: s.selectedLevel,
    mode: s.mode,
    decks: s.decks,
    currentCardId: s.currentCard?.id ?? null,
    ageConfirmed: s.ageConfirmed,
    heatStart: s.heatStart,
    bdsmOn: s.bdsmOn,
  };
}

function ensureDeck(
  decks: Record<string, string[]>,
  mode: Mode,
  level: LevelId,
  bdsmOn: boolean,
): { decks: Record<string, string[]>; remaining: string[] } {
  const key = deckKey(mode, level);
  const existing = decks[key];
  if (existing) return { decks, remaining: existing };
  const remaining = fisherYatesShuffle(getDeckIds(mode, level, bdsmOn));
  return { decks: { ...decks, [key]: remaining }, remaining };
}

function migrate(raw: unknown): SavedState | null {
  if (!raw || typeof raw !== "object") return null;
  const s = raw as Partial<SavedState> & { version?: number };
  const players = s.players;
  if (!Array.isArray(players) || players.length < 2) return null;
  const oldVersion = Number(s.version) || 1;
  const savedThresholds = Array.isArray(s.unlockThresholds)
    ? s.unlockThresholds.map((n) => Math.max(0, Math.min(99, Number(n) || 0)))
    : [];
  const unlockThresholds =
    oldVersion < 10 || savedThresholds.length !== DEFAULT_THRESHOLDS.length
      ? [...DEFAULT_THRESHOLDS]
      : savedThresholds;
  const allowed = ALL_LEVELS as LevelId[];
  return {
    version: SAVE_VERSION,
    screen:
      oldVersion < 14 ? "home" : s.screen === "playing" || s.screen === "setup" ? s.screen : "home",
    players: [
      {
        name: String(players[0]?.name ?? ""),
        gender: players[0]?.gender === "female" ? "female" : "male",
        drinks: oldVersion < 14 ? 0 : Number(players[0]?.drinks) || 0,
      },
      {
        name: String(players[1]?.name ?? ""),
        gender: players[1]?.gender === "female" ? "female" : "male",
        drinks: oldVersion < 14 ? 0 : Number(players[1]?.drinks) || 0,
      },
    ],
    currentPlayerIndex: s.currentPlayerIndex === 1 ? 1 : 0,
    unlockThresholds:
      oldVersion < 14 || savedThresholds.length !== DEFAULT_THRESHOLDS.length
        ? [...DEFAULT_THRESHOLDS]
        : unlockThresholds,
    selectedLevel:
      oldVersion < 14
        ? 1
        : allowed.includes(s.selectedLevel as LevelId)
          ? (s.selectedLevel as LevelId)
          : 1,
    mode:
      s.mode === "neverHaveIEver" ||
      s.mode === "wouldYouRather" ||
      s.mode === "inBed" ||
      s.mode === "positions" ||
      s.mode === "wheel" ||
      s.mode === "roleplay" ||
      s.mode === "dice" ||
      s.mode === "power" ||
      s.mode === "tripleWheel" ||
      s.mode === "chaos"
        ? s.mode
        : "truthDare",
    decks: oldVersion < 14 ? {} : s.decks && typeof s.decks === "object" ? s.decks : {},
    currentCardId:
      oldVersion < 14 ? null : typeof s.currentCardId === "string" ? s.currentCardId : null,
    ageConfirmed: Boolean(s.ageConfirmed),
    heatStart: oldVersion < 14 ? false : Boolean(s.heatStart),
    bdsmOn: s.bdsmOn !== false,
  };
}

export const useGameStore = create<GameStore>((set, get) => ({
  hydrated: false,
  screen: "home",
  players: defaultPlayers(),
  currentPlayerIndex: 0,
  unlockThresholds: [...DEFAULT_THRESHOLDS],
  selectedLevel: 1,
  mode: "truthDare",
  decks: {},
  currentCard: null,
  deckEmpty: false,
  ageConfirmed: false,
  justUnlocked: null,
  heatStart: false,
  bdsmOn: true,
  deckRevision: 0,

  applyDeck: (cards) => {
    const ok = setCustomDeck(cards);
    if (!ok) return false;
    set((s) => ({
      decks: {},
      currentCard: null,
      deckEmpty: false,
      deckRevision: s.deckRevision + 1,
    }));
    persist(snapshot(get()));
    return true;
  },

  hydrate: () => {
    if (get().hydrated) return;
    loadStoredCustomDeck();
    set((s) => ({ deckRevision: s.deckRevision + 1 }));
    const alreadyMoved = get().screen !== "home";
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) {
        set({ hydrated: true });
        return;
      }
      const saved = migrate(JSON.parse(raw) as unknown);
      if (!saved) {
        set({ hydrated: true });
        return;
      }
      if (alreadyMoved) {
        set({ hydrated: true });
        return;
      }
      const card = saved.currentCardId ? getCardById(saved.currentCardId) : null;
      const key = deckKey(saved.mode, saved.selectedLevel);
      const remaining = saved.decks[key] ?? [];
      set({
        hydrated: true,
        screen: saved.screen,
        players: saved.players,
        currentPlayerIndex: saved.currentPlayerIndex,
        unlockThresholds: saved.unlockThresholds,
        selectedLevel: saved.selectedLevel,
        mode: saved.mode,
        decks: saved.decks,
        currentCard: card ?? null,
        deckEmpty: !card && remaining.length === 0 && Boolean(saved.decks[key]),
        ageConfirmed: saved.ageConfirmed,
        heatStart: saved.heatStart,
        bdsmOn: saved.bdsmOn,
      });
    } catch {
      set({ hydrated: true });
    }
  },

  confirmAge: () => {
    set({ ageConfirmed: true });
    persist(snapshot(get()));
  },

  goToSetup: () => {
    set({ ageConfirmed: true, screen: "setup" });
    persist(snapshot(get()));
  },

  setScreen: (screen) => {
    set({ screen });
    persist(snapshot(get()));
  },

  setPlayerName: (index, name) => {
    const players = [...get().players] as [Player, Player];
    players[index] = { ...players[index], name };
    set({ players });
    persist(snapshot(get()));
  },

  setPlayerGender: (index, gender) => {
    const players = [...get().players] as [Player, Player];
    players[index] = { ...players[index], gender };
    set({ players });
    persist(snapshot(get()));
  },

  setThreshold: (levelFrom2, value) => {
    const unlockThresholds = [...get().unlockThresholds];
    unlockThresholds[levelFrom2] = Math.max(1, Math.min(99, value));
    set({ unlockThresholds });
    persist(snapshot(get()));
  },

  setThresholds: (values) => {
    set({ unlockThresholds: values.map((n) => Math.max(1, Math.min(99, n))) });
    persist(snapshot(get()));
  },

  startPlaying: () => {
    const prev = get().players;
    const heat = get().heatStart;
    const prevThresholds = get().unlockThresholds;
    const players: [Player, Player] = [
      {
        name: prev[0].name.trim() || "ผู้เล่น 1",
        gender: prev[0].gender,
        drinks: 0,
      },
      {
        name: prev[1].name.trim() || "ผู้เล่น 2",
        gender: prev[1].gender,
        drinks: 0,
      },
    ];
    set({
      ageConfirmed: true,
      screen: "playing",
      players,
      currentPlayerIndex: 0,
      selectedLevel: heat ? 4 : 1,
      // Keep thresholds the player customised in Settings. A stored heat preset
      // (contains 0, which Settings can never produce) falls back to the defaults.
      unlockThresholds: heat
        ? [0, 0, 0, 2, 4, 6, 8, 10]
        : prevThresholds.length === DEFAULT_THRESHOLDS.length && prevThresholds.every((n) => n >= 1)
          ? [...prevThresholds]
          : [...DEFAULT_THRESHOLDS],
      mode: "truthDare",
      decks: {},
      currentCard: null,
      deckEmpty: false,
      justUnlocked: null,
    });
    persist(snapshot(get()));
  },

  setHeatStart: (value) => {
    set({ heatStart: value });
    persist(snapshot(get()));
  },

  setBdsmOn: (value) => {
    set({ bdsmOn: value, decks: {}, currentCard: null, deckEmpty: false });
    persist(snapshot(get()));
  },

  resumePlaying: () => {
    const players = [...get().players] as [Player, Player];
    if (!players[0].name.trim()) players[0] = { ...players[0], name: "ผู้เล่น 1" };
    if (!players[1].name.trim()) players[1] = { ...players[1], name: "ผู้เล่น 2" };
    set({ screen: "playing", players });
    persist(snapshot(get()));
  },

  dismissUnlock: () => set({ justUnlocked: null }),

  selectMode: (mode) => {
    const s = get();
    if (mode === s.mode) return;
    if (mode === "roleplay" && s.selectedLevel < 5) {
      if (!isLevelUnlocked(5, totalDrinksOf(s.players), s.unlockThresholds)) return;
      set({ mode, selectedLevel: 5, currentCard: null, deckEmpty: false });
    } else {
      set({ mode, currentCard: null, deckEmpty: false });
    }
    persist(snapshot(get()));
  },

  selectLevel: (level) => {
    const s = get();
    if (!isLevelUnlocked(level, totalDrinksOf(s.players), s.unlockThresholds)) return;
    if (level === s.selectedLevel) return;
    const mode = level < 5 && s.mode === "roleplay" ? "truthDare" : s.mode;
    set({ selectedLevel: level, mode, currentCard: null, deckEmpty: false });
    persist(snapshot(get()));
  },

  drawCard: () => {
    const s = get();
    const prepared = ensureDeck(s.decks, s.mode, s.selectedLevel, s.bdsmOn);
    const remaining = prepared.remaining;
    if (remaining.length === 0) {
      set({ decks: prepared.decks, currentCard: null, deckEmpty: true });
      persist(snapshot({ ...get(), decks: prepared.decks, currentCard: null }));
      return;
    }
    let rest = [...prepared.remaining];
    let card: GameCard | null = null;
    while (rest.length > 0) {
      const nextId = rest[0]!;
      rest = rest.slice(1);
      const found = getCardById(nextId);
      if (found) {
        card = found;
        break;
      }
    }
    const key = deckKey(s.mode, s.selectedLevel);
    const decks = { ...prepared.decks, [key]: rest };
    if (!card) {
      set({ decks, currentCard: null, deckEmpty: true });
      persist(snapshot({ ...get(), decks, currentCard: null }));
      return;
    }
    set({ decks, currentCard: card, deckEmpty: false });
    persist(snapshot({ ...get(), decks, currentCard: card }));
  },

  reshuffleCurrent: () => {
    const s = get();
    const key = deckKey(s.mode, s.selectedLevel);
    const remaining = fisherYatesShuffle(getDeckIds(s.mode, s.selectedLevel, s.bdsmOn));
    const decks = { ...s.decks, [key]: remaining };
    set({ decks, currentCard: null, deckEmpty: remaining.length === 0 });
    persist(snapshot({ ...get(), decks, currentCard: null }));
  },

  drink: (index) => {
    const s = get();
    const before = totalDrinksOf(s.players);
    const players = [...s.players] as [Player, Player];
    players[index] = { ...players[index], drinks: players[index].drinks + 1 };
    const after = totalDrinksOf(players);
    let justUnlocked: LevelId | null = null;
    for (const level of ALL_LEVELS.filter((lv) => lv !== 1)) {
      const was = isLevelUnlocked(level, before, s.unlockThresholds);
      const now = isLevelUnlocked(level, after, s.unlockThresholds);
      if (!was && now) justUnlocked = level;
    }
    set({ players, justUnlocked });
    persist(snapshot(get()));
  },

  completeCard: () => {
    const next: 0 | 1 = get().currentPlayerIndex === 0 ? 1 : 0;
    set({ currentPlayerIndex: next, currentCard: null, deckEmpty: false });
    persist(snapshot(get()));
  },

  skipWithDrink: () => {
    get().drink(get().currentPlayerIndex);
    get().completeCard();
  },

  nextWithoutDrink: () => {
    get().completeCard();
  },

  resetGame: () => {
    const s = get();
    const players: [Player, Player] = [
      { ...s.players[0], drinks: 0 },
      { ...s.players[1], drinks: 0 },
    ];
    set({
      screen: "setup",
      players,
      currentPlayerIndex: 0,
      selectedLevel: 1,
      mode: "truthDare",
      decks: {},
      currentCard: null,
      deckEmpty: false,
      justUnlocked: null,
    });
    persist(snapshot(get()));
  },

  goHome: () => {
    set({ screen: "home", currentCard: null });
    persist(snapshot(get()));
  },
}));

export function useTotalDrinks(): number {
  return useGameStore((s) => s.players[0].drinks + s.players[1].drinks);
}
