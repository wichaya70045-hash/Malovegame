import type { GameCard, LevelId, PoseId } from "./types";

export function t(level: LevelId, n: number, text: string, bdsm = false): GameCard {
  return { id: `t${level}-${n}`, kind: "truth", text, ...(bdsm ? { bdsm } : {}) };
}
export function d(level: LevelId, n: number, text: string, time?: number, bdsm = false): GameCard {
  return { id: `d${level}-${n}`, kind: "dare", text, time, ...(bdsm ? { bdsm } : {}) };
}
export function n(level: LevelId, num: number, text: string, bdsm = false): GameCard {
  return { id: `n${level}-${num}`, kind: "never", text, ...(bdsm ? { bdsm } : {}) };
}
export function r(level: LevelId, num: number, optionA: string, optionB: string, bdsm = false): GameCard {
  return { id: `r${level}-${num}`, kind: "rather", text: "เลือกเลย", optionA, optionB, ...(bdsm ? { bdsm } : {}) };
}
export function b(level: LevelId, n: number, text: string, time: number, bdsm = false): GameCard {
  return { id: `b${level}-${n}`, kind: "live", text, time, ...(bdsm ? { bdsm } : {}) };
}
export function p(
  level: LevelId,
  n: number,
  title: string,
  instruction: string,
  pose: PoseId,
  time?: number,
  bdsm = false,
): GameCard {
  return { id: `p${level}-${n}`, kind: "pose", text: title, optionA: instruction, pose, time, ...(bdsm ? { bdsm } : {}) };
}
export function rp(
  level: LevelId,
  n: number,
  title: string,
  roles: string,
  script: string,
  time?: number,
  bdsm = false,
): GameCard {
  return { id: `rp${level}-${n}`, kind: "role", text: title, optionA: roles, optionB: script, time, ...(bdsm ? { bdsm } : {}) };
}
