import type { GameCard, LevelId } from "./types";

function sourceLevel(id: string): LevelId {
  const match = id.match(/^[a-z]+(\d+)-/i);
  const level = Number(match?.[1]);
  if (level >= 1 && level <= 9) return level as LevelId;
  return 1;
}

function heatOf(text: string): LevelId | 0 {
  const s = text.replace(/\s+/g, "");
  if (
    /น้ำตา|ห้องลับ|เป็นของทั้ง|ปากสองรอบ|เปิดม่าน|ห้ามเอาออก|บีบคอ|รอบสี่|ไม่จำกัดรอบ|ขัง|ประมูล|ทั้งบ้าน/.test(
      s,
    )
  ) {
    return 9;
  }
  if (
    /ทั้งคืน|ไม่ยั้ง|ทุกห้อง|หลายรอบ|แตกใน|แตกปาก|จนขาอ่อน|จนขอแล้วยัง|ไม่มีแรง|ใช้ต่อทั้งที่|สองรอบ/.test(
      s,
    )
  ) {
    return 8;
  }
  if (/ทุกท่า|จัดเต็ม|อุ้ม|หน้ากระจกจน|พื้นคว่ำ|ไม่เอาออก|เปลี่ยนท่าโดยไม่/.test(s)) {
    return 7;
  }
  if (
    /เย็ด|ท่าหมา|ใส่ลึก|ถูกใส่|ใส่แล้ว|ใส่ต่อ|ใส่ค้าง|ใส่เข้า|ใส่แค่|ตอนใส่|แล้วใส่|ใส่แรง|ใส่ช้า|นั่งบนปาก|แตก/.test(
      s,
    ) &&
    /ห้ามเสร็จ|มัด|ปิดตา|เจ้านาย|คนใช้|ลงโทษ|คำหยุด|บทนำ|บทตาม/.test(s)
  ) {
    return 6;
  }
  if (
    /เย็ด|ท่าหมา|ใส่ลึก|ถูกใส่|ใส่แล้ว|ใส่ต่อ|ใส่ค้าง|ใส่เข้า|ใส่แค่|ตอนใส่|แล้วใส่|ใส่แรง|ใส่ช้า|นั่งบนปาก/.test(
      s,
    )
  ) {
    return 5;
  }
  if (/ขึ้นคร่อม|ขย่ม/.test(s) && !/ผ่านผ้า|ขย่มผ้า/.test(s)) return 5;
  if (
    /แตก|อมจน|ถูกอม|อยากอม|เลียก้น|เลียตรง|ใช้นิ้ว|นิ้ววน|ใต้กางเกง|ในกางเกง|หัวนม|เกือบเสร็จ|ทำให้เสร็จ|หว่างขา|มัดมือ|มัด/.test(
      s,
    )
  ) {
    return 4;
  }
  if (/เลีย(?!หู|คอ|หลังหู|ไหปลาร้า|นิ้ว)/.test(s)) return 4;
  if (/ผ่านผ้า|ขย่มผ้า|ถอด|คำหยาบ|ชุดชั้นใน|กางเกง|ตบก้น|ดูดหัว|ถูจน|เสียว|คราง/.test(s)) return 3;
  if (/จูบ|กอด|นวด|ลูบ|ต้นขา|นั่งตัก|ใต้เสื้อ|ปิดตา/.test(s)) return 2;
  return 0;
}

export function cardHeat(card: GameCard): LevelId {
  const blob = [card.text, card.optionA, card.optionB].filter(Boolean).join(" ");
  const detected = heatOf(blob);
  if (detected !== 0) return detected;
  return sourceLevel(card.id);
}
