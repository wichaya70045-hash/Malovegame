import {
  ALL_LEVELS,
  LEVELS,
  POSE_IDS,
  type CardKind,
  type GameCard,
  type LevelId,
  type PoseId,
} from "./types";

/**
 * Plain-text deck format (one file per level, or several levels in one file).
 *
 *   @level 5                      starts a level
 *   ## dare                       starts a section: truth | dare | never | rather | inbed | pose | role
 *   [60s] [bdsm] card text        optional tags, then the text
 *   A text || B text              "rather" cards: option A || option B
 *   [pose:doggy] [60s] title || instruction        "pose" cards
 *   [90s] title || roles || script                 "role" cards
 *   // comment                    ignored
 *
 * Time tags accept 90s, 2m or 1:30. Timers apply to dare, inbed, pose and role cards.
 */

export const SECTIONS = ["truth", "dare", "never", "rather", "inbed", "pose", "role"] as const;
export type Section = (typeof SECTIONS)[number];

const SECTION_KIND: Record<Section, CardKind> = {
  truth: "truth",
  dare: "dare",
  never: "never",
  rather: "rather",
  inbed: "live",
  pose: "pose",
  role: "role",
};
const KIND_SECTION = Object.fromEntries(
  (Object.entries(SECTION_KIND) as [Section, CardKind][]).map(([s, k]) => [k, s]),
) as Record<CardKind, Section>;
const KIND_ID: Record<CardKind, string> = {
  truth: "t",
  dare: "d",
  never: "n",
  rather: "r",
  live: "b",
  pose: "p",
  role: "rp",
};
const PARTS: Record<Section, number> = {
  truth: 1,
  dare: 1,
  never: 1,
  rather: 2,
  inbed: 1,
  pose: 2,
  role: 3,
};
const TIMED: Section[] = ["dare", "inbed", "pose", "role"];

export const MIN_SECONDS = 5;
export const MAX_SECONDS = 3600;
export const MAX_TEXT = 600;
export const MAX_FILE_BYTES = 3 * 1024 * 1024;

/* ------------------------------ export ------------------------------ */

export function formatSeconds(total: number): string {
  return `${Math.round(total)}s`;
}

function cardLine(card: GameCard): string {
  const tags: string[] = [];
  if (card.kind === "pose" && card.pose) tags.push(`[pose:${card.pose}]`);
  if (card.time) tags.push(`[${formatSeconds(card.time)}]`);
  if (card.bdsm) tags.push("[bdsm]");
  const body =
    card.kind === "rather"
      ? `${card.optionA ?? ""} || ${card.optionB ?? ""}`
      : card.kind === "pose"
        ? `${card.text} || ${card.optionA ?? ""}`
        : card.kind === "role"
          ? `${card.text} || ${card.optionA ?? ""} || ${card.optionB ?? ""}`
          : card.text;
  return [...tags, body].join(" ");
}

export const FORMAT_GUIDE = [
  "// รูปแบบไฟล์ (บรรทัดที่ขึ้นต้นด้วย // คือหมายเหตุ เกมจะข้ามไป)",
  "// @level N      เริ่มเลเวล N (1-9)      ## ชื่อหมวด   หมวดที่ใช้ได้: truth dare never rather inbed pose role",
  "// 1 บรรทัด = 1 ใบ  ใส่ {me} {you} ในข้อความเพื่อแทนชื่อผู้เล่นได้",
  "// เวลา:   [60s] หรือ [2m] หรือ [1:30]   ใช้ได้กับ dare inbed pose role   (inbed ต้องมีเวลา)",
  "// BDSM:   [bdsm]   ถ้าปิดโหมด BDSM ในเกม ใบนี้จะไม่ถูกสุ่ม",
  "// rather: ข้อ A || ข้อ B",
  "// pose:   [pose:รหัสท่า] ชื่อ || คำอธิบาย      role: ชื่อ || บทบาท || สคริปต์",
  `// รหัสท่า: ${POSE_IDS.join(" ")}`,
];

/** Text for one level, using the cards that currently play at that level. */
export function exportLevelText(level: LevelId, cards: GameCard[]): string {
  const meta = LEVELS.find((l) => l.id === level);
  const lines: string[] = [...FORMAT_GUIDE, "", `@level ${level} ${meta?.name ?? ""}`.trimEnd()];
  const inLevel = cards.filter((c) => c.level === level);
  for (const section of SECTIONS) {
    const kind = SECTION_KIND[section];
    const group = inLevel.filter((c) => c.kind === kind);
    if (group.length === 0) continue;
    lines.push("", `## ${section}`);
    for (const card of group) lines.push(cardLine(card));
  }
  return lines.join("\n") + "\n";
}

export function exportAllLevelTexts(cards: GameCard[]): Record<LevelId, string> {
  const out = {} as Record<LevelId, string>;
  for (const level of ALL_LEVELS) out[level] = exportLevelText(level, cards);
  return out;
}

/** One combined file for all levels (guide printed once). */
export function exportCombinedText(cards: GameCard[]): string {
  const parts = ALL_LEVELS.map((level) =>
    exportLevelText(level, cards)
      .split("\n")
      .slice(FORMAT_GUIDE.length + 1)
      .join("\n"),
  );
  return [...FORMAT_GUIDE, "", ...parts].join("\n").replace(/\n{3,}/g, "\n\n");
}

/* ------------------------------ parse ------------------------------ */

export interface Issue {
  file: string;
  line: number;
  message: string;
}

export interface ParseResult {
  /** Valid cards, each with an explicit level and a unique id. */
  cards: GameCard[];
  /** Levels that have at least one valid card (these replace the level in the game). */
  levels: LevelId[];
  errors: Issue[];
  warnings: Issue[];
  skipped: number;
}

export interface DeckSummaryRow {
  level: LevelId;
  total: number;
  timed: number;
  bdsm: number;
}

export function summarize(cards: GameCard[]): DeckSummaryRow[] {
  return ALL_LEVELS.map((level) => {
    const own = cards.filter((c) => c.level === level);
    return {
      level,
      total: own.length,
      timed: own.filter((c) => c.time).length,
      bdsm: own.filter((c) => c.bdsm).length,
    };
  }).filter((row) => row.total > 0);
}

function parseTime(raw: string): number | null {
  const s = raw.trim().toLowerCase();
  let m = /^(\d{1,3}):(\d{1,2})$/.exec(s);
  if (m) {
    const mins = Number(m[1]);
    const secs = Number(m[2]);
    return secs < 60 ? mins * 60 + secs : null;
  }
  m = /^(\d+)\s*(s|sec|m|min)?$/.exec(s);
  if (!m) return null;
  const n = Number(m[1]);
  return m[2] === "m" || m[2] === "min" ? n * 60 : n;
}

function isLevel(n: number): n is LevelId {
  return (ALL_LEVELS as number[]).includes(n);
}

interface Block {
  file: string;
  level: LevelId;
  cards: Omit<GameCard, "id">[];
}

function parseOne(
  file: string,
  text: string,
  errors: Issue[],
  warnings: Issue[],
): { blocks: Block[]; skipped: number } {
  const blocks: Block[] = [];
  let current: Block | null = null;
  let section: Section | null = null;
  let skipped = 0;
  const lines = text.replace(/^\uFEFF/, "").split(/\r\n|\r|\n/);

  lines.forEach((rawLine, i) => {
    const lineNo = i + 1;
    const line = rawLine.trim();
    if (!line || line.startsWith("//")) return;
    const fail = (message: string) => {
      errors.push({ file, line: lineNo, message });
      skipped += 1;
    };

    if (line.startsWith("@")) {
      const m = /^@level\s+(\d+)\b/i.exec(line);
      if (!m) {
        errors.push({ file, line: lineNo, message: "หัวเลเวลต้องเป็น @level ตามด้วยเลข 1-9" });
        current = null;
        section = null;
        return;
      }
      const n = Number(m[1]);
      if (!isLevel(n)) {
        errors.push({ file, line: lineNo, message: `เลเวล ${n} ไม่มีในเกม (ใช้ 1-9)` });
        current = null;
        section = null;
        return;
      }
      current = { file, level: n, cards: [] };
      blocks.push(current);
      section = null;
      return;
    }

    if (line.startsWith("##")) {
      const name = line.slice(2).trim().toLowerCase();
      if (!current) {
        errors.push({ file, line: lineNo, message: "ต้องมี @level ก่อนหัวหมวด" });
        return;
      }
      if ((SECTIONS as readonly string[]).includes(name)) section = name as Section;
      else {
        section = null;
        errors.push({
          file,
          line: lineNo,
          message: `ไม่รู้จักหมวด "${name}" (ใช้ ${SECTIONS.join(" ")})`,
        });
      }
      return;
    }

    if (!current || !section) return fail("ใบนี้ไม่อยู่ใต้ @level และ ## หมวด");

    let rest = line;
    let time: number | undefined;
    let bdsm = false;
    let pose: PoseId | undefined;
    let bad = false;
    while (rest.startsWith("[")) {
      const end = rest.indexOf("]");
      if (end < 0) {
        fail("วงเล็บ [ ไม่ปิด");
        bad = true;
        break;
      }
      const tag = rest.slice(1, end).trim();
      rest = rest.slice(end + 1).trim();
      const poseMatch = /^pose\s*:\s*(\w+)$/i.exec(tag);
      if (tag.toLowerCase() === "bdsm") bdsm = true;
      else if (poseMatch) {
        const id = poseMatch[1]!;
        if ((POSE_IDS as readonly string[]).includes(id)) pose = id as PoseId;
        else {
          fail(`ไม่รู้จักรหัสท่า "${id}"`);
          bad = true;
          break;
        }
      } else {
        const secs = parseTime(tag);
        if (secs === null) {
          fail(`แท็ก [${tag}] ไม่ถูกต้อง (เวลาใช้ 90s, 2m หรือ 1:30)`);
          bad = true;
          break;
        }
        if (secs < MIN_SECONDS || secs > MAX_SECONDS) {
          fail(`เวลา ${secs} วินาทีต้องอยู่ระหว่าง ${MIN_SECONDS}-${MAX_SECONDS}`);
          bad = true;
          break;
        }
        time = secs;
      }
    }
    if (bad) return;

    const parts = rest.split(/\s*\|\|\s*/).map((p) => p.trim());
    if (parts.length !== PARTS[section] || parts.some((p) => !p)) {
      return fail(
        PARTS[section] === 1
          ? "ข้อความว่าง หรือมี || เกินมา"
          : `หมวด ${section} ต้องมี ${PARTS[section]} ส่วน คั่นด้วย ||`,
      );
    }
    if (parts.some((p) => p.length > MAX_TEXT)) return fail(`ข้อความยาวเกิน ${MAX_TEXT} ตัวอักษร`);
    if (section === "pose" && !pose) return fail("หมวด pose ต้องมีแท็ก [pose:รหัสท่า]");
    if (pose && section !== "pose") {
      warnings.push({
        file,
        line: lineNo,
        message: "แท็ก [pose:...] ใช้เฉพาะหมวด pose จึงถูกข้าม",
      });
      pose = undefined;
    }
    if (time !== undefined && !TIMED.includes(section)) {
      warnings.push({ file, line: lineNo, message: `หมวด ${section} ไม่มีตัวจับเวลา จึงข้ามเวลา` });
      time = undefined;
    }
    if (section === "inbed" && time === undefined) {
      warnings.push({ file, line: lineNo, message: "inbed ต้องมีเวลา ใช้ค่าเริ่มต้น 60 วินาที" });
      time = 60;
    }
    if (section === "role" && current.level < 5) {
      warnings.push({
        file,
        line: lineNo,
        message: "สวมบทเปิดที่ LV5 ขึ้นไป ใบนี้จะไม่ถูกสุ่มที่เลเวลต่ำกว่า",
      });
    }

    const kind = SECTION_KIND[section];
    const card: Omit<GameCard, "id"> = { kind, text: "", level: current.level };
    if (section === "rather") {
      card.text = "เลือกเลย";
      card.optionA = parts[0];
      card.optionB = parts[1];
    } else if (section === "pose") {
      card.text = parts[0]!;
      card.optionA = parts[1];
      card.pose = pose;
    } else if (section === "role") {
      card.text = parts[0]!;
      card.optionA = parts[1];
      card.optionB = parts[2];
    } else card.text = parts[0]!;
    if (time !== undefined) card.time = time;
    if (bdsm) card.bdsm = true;
    current.cards.push(card);
  });

  return { blocks, skipped };
}

/** Parses one or more uploaded text files. Later files override earlier ones for the same level. */
export function parseDeckFiles(files: { name: string; text: string }[]): ParseResult {
  const errors: Issue[] = [];
  const warnings: Issue[] = [];
  const byLevel = new Map<LevelId, Block>();
  let skipped = 0;

  for (const file of files) {
    const parsed = parseOne(file.name, file.text, errors, warnings);
    skipped += parsed.skipped;
    for (const block of parsed.blocks) {
      if (block.cards.length === 0) {
        warnings.push({
          file: file.name,
          line: 0,
          message: `เลเวล ${block.level} ไม่มีไพ่ที่ใช้ได้เลย จึงใช้ไพ่เดิมของเลเวลนี้ต่อ`,
        });
        continue;
      }
      if (byLevel.has(block.level)) {
        warnings.push({
          file: file.name,
          line: 0,
          message: `เลเวล ${block.level} ซ้ำกับไฟล์ ${byLevel.get(block.level)!.file} ใช้ของไฟล์นี้แทน`,
        });
      }
      byLevel.set(block.level, block);
    }
  }

  const cards: GameCard[] = [];
  const levels = [...byLevel.keys()].sort((a, b) => a - b);
  for (const level of levels) {
    const counters: Partial<Record<CardKind, number>> = {};
    for (const card of byLevel.get(level)!.cards) {
      const n = (counters[card.kind] = (counters[card.kind] ?? 0) + 1);
      cards.push({ ...card, id: `u${level}-${KIND_ID[card.kind]}${n}` });
    }
  }
  return { cards, levels, errors, warnings, skipped };
}

/** Replaces the given levels in `current` with `incoming`, leaving the rest as they are. */
export function mergeLevels(
  current: GameCard[],
  incoming: GameCard[],
  levels: LevelId[],
): GameCard[] {
  const replaced = new Set<LevelId>(levels);
  return [...current.filter((c) => c.level === undefined || !replaced.has(c.level)), ...incoming];
}

export { KIND_SECTION };
