/** Unbiased Fisher–Yates shuffle. Never use sort(() => Math.random() - 0.5). */
export function fisherYatesShuffle<T>(items: readonly T[]): T[] {
  const deck = items.slice();
  for (let i = deck.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    const tmp = deck[i]!;
    deck[i] = deck[j]!;
    deck[j] = tmp;
  }
  return deck;
}
