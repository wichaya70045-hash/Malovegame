export type Gender = "male" | "female";
export type Screen = "home" | "setup" | "playing";
export type Mode =
  | "truthDare"
  | "neverHaveIEver"
  | "wouldYouRather"
  | "inBed"
  | "positions"
  | "wheel"
  | "roleplay"
  | "dice"
  | "power"
  | "tripleWheel"
  | "chaos";
export type CardKind = "truth" | "dare" | "never" | "rather" | "live" | "pose" | "role";
export const POSE_IDS = [
  "cuddle",
  "lap",
  "wallKiss",
  "grind",
  "missionary",
  "cowgirl",
  "reverse",
  "doggy",
  "spoon",
  "wall",
  "chair",
  "standing",
  "lotus",
  "legsUp",
  "oral",
  "sixtyNine",
  "prone",
  "edge",
  "facesit",
  "bentOver",
  "kneeling",
  "seatedBack",
  "carry",
  "squat",
  "table",
  "frog",
  "press",
  "sideFace",
  "bound",
  "spank",
  "blind",
] as const;
export type PoseId = (typeof POSE_IDS)[number];
export type LevelId = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9;

export interface Player {
  name: string;
  gender: Gender;
  drinks: number;
}

export interface GameCard {
  id: string;
  kind: CardKind;
  text: string;
  time?: number;
  optionA?: string;
  optionB?: string;
  pose?: PoseId;
  bdsm?: boolean;
  /** Set on cards that come from an imported deck file; built-in cards derive it from their text. */
  level?: LevelId;
}

export interface LevelMeta {
  id: LevelId;
  name: string;
  tagline: string;
}

export interface LevelContent {
  truths: GameCard[];
  dares: GameCard[];
  neverHaveIEver: GameCard[];
  wouldYouRather: GameCard[];
  inBed: GameCard[];
  positions: GameCard[];
  roleplay?: GameCard[];
}

export const ALL_LEVELS: LevelId[] = [1, 2, 3, 4, 5, 6, 7, 8, 9];
export const OPEN_LEVELS: LevelId[] = [1, 2, 3, 4, 5, 6, 7, 8];
export const SECRET_LEVEL: LevelId = 9;

export const LEVELS: LevelMeta[] = [
  { id: 1, name: "หวาน", tagline: "คุย กอด ยังไม่ลามก" },
  { id: 2, name: "ใกล้", tagline: "จูบ นวด ลูบ" },
  { id: 3, name: "ไฟลุก", tagline: "ถอด ขย่มผ้า คำหยาบ" },
  { id: 4, name: "ร้อน", tagline: "ปาก มือ ใต้ผ้า" },
  { id: 5, name: "เสียว", tagline: "เริ่มเย็ด ทำให้เสร็จ" },
  { id: 6, name: "ยอม", tagline: "สั่ง มัด ปิดตา" },
  { id: 7, name: "จัดเต็ม", tagline: "ทุกท่า หลายที่" },
  { id: 8, name: "ไม่ยั้ง", tagline: "หนัก ไม่พัก" },
  { id: 9, name: "ห้องลับ", tagline: "ไม่มีขีด ห้ามเล่า" },
];

export const DEFAULT_THRESHOLDS = [1, 2, 3, 4, 5, 6, 8, 10] as const;

export const LEVEL_EMOJI: Record<LevelId, string> = {
  1: "🍯",
  2: "🌸",
  3: "🔥",
  4: "🌶️",
  5: "💦",
  6: "🖤",
  7: "❤️‍🔥",
  8: "😈",
  9: "🔮",
};

export type ModeGroupId = "cards" | "bed" | "mini";

export const MODE_META: Record<
  Mode,
  { label: string; short: string; emoji: string; group: ModeGroupId }
> = {
  truthDare: { label: "จริง / ท้า", short: "จริงท้า", emoji: "💬", group: "cards" },
  neverHaveIEver: { label: "ฉันไม่เคย", short: "ไม่เคย", emoji: "🚫", group: "cards" },
  wouldYouRather: { label: "เลือกอะไร", short: "เลือก", emoji: "⚖️", group: "cards" },
  inBed: { label: "บนเตียง", short: "เตียง", emoji: "🛏️", group: "bed" },
  positions: { label: "สุ่มท่า", short: "ท่า", emoji: "💋", group: "bed" },
  roleplay: { label: "สวมบท", short: "บท", emoji: "🎭", group: "bed" },
  wheel: { label: "วงล้อเมา", short: "วงล้อ", emoji: "🎡", group: "mini" },
  dice: { label: "ลูกเต๋า 3 ลูก", short: "เต๋า", emoji: "🎲", group: "mini" },
  power: { label: "สลับอำนาจ", short: "อำนาจ", emoji: "👑", group: "mini" },
  tripleWheel: { label: "ที่ ท่า บท", short: "สามวง", emoji: "🎯", group: "mini" },
  chaos: { label: "กฎค้าง", short: "กฎค้าง", emoji: "🌀", group: "mini" },
};

export const MODE_GROUPS: { id: ModeGroupId; label: string; emoji: string; modes: Mode[] }[] = [
  { id: "cards", label: "ไพ่", emoji: "🃏", modes: ["truthDare", "neverHaveIEver", "wouldYouRather"] },
  { id: "bed", label: "เตียง", emoji: "🔥", modes: ["inBed", "positions", "roleplay"] },
  { id: "mini", label: "มินิเกม", emoji: "🎲", modes: ["wheel", "dice", "power", "tripleWheel", "chaos"] },
];

export const MODES: { id: Mode; label: string }[] = (
  Object.keys(MODE_META) as Mode[]
).map((id) => ({ id, label: MODE_META[id].label }));

export const SAVE_VERSION = 14;
export const SAVE_KEY = "ultimate-couple-game-v1";

export function deckKey(mode: Mode, level: LevelId): string {
  return `${mode}-${level}`;
}
