import { Heart, Sparkles } from "lucide-react";
import { useGameStore } from "@/lib/game/store";
import { cn } from "@/lib/utils";

const HIGHLIGHTS = [
  { emoji: "🃏", label: "ไพ่เพียบ" },
  { emoji: "🎲", label: "ลูกเต๋า" },
  { emoji: "👑", label: "อำนาจ" },
  { emoji: "🌀", label: "กฎค้าง" },
];

export function HomeScreen() {
  const goToSetup = useGameStore((s) => s.goToSetup);
  const startPlaying = useGameStore((s) => s.startPlaying);
  const resumePlaying = useGameStore((s) => s.resumePlaying);
  const confirmAge = useGameStore((s) => s.confirmAge);
  const players = useGameStore((s) => s.players);
  const decks = useGameStore((s) => s.decks);

  const canResume =
    Boolean(players[0].name.trim()) &&
    (players[0].drinks + players[1].drinks > 0 || Object.keys(decks).length > 0);

  function start() {
    startPlaying();
  }

  function resume() {
    confirmAge();
    resumePlaying();
  }

  return (
    <main className="relative z-10 mx-auto flex min-h-dvh w-full max-w-md flex-col items-center justify-center px-6 py-12 pb-28 text-center">
      <div className="rise-in mb-5 flex size-20 items-center justify-center rounded-2xl bg-elevated glow-primary">
        <Heart className="size-10 text-primary" fill="currentColor" strokeWidth={1.5} />
      </div>
      <p
        className="rise-in text-xs font-medium uppercase tracking-[0.22em] text-champagne"
        style={{ animationDelay: "60ms" }}
      >
        18+ Couple Night
      </p>
      <h1
        className="rise-in mt-3 font-display text-4xl font-semibold tracking-tight"
        style={{ animationDelay: "100ms" }}
      >
        💕 เกมคู่รัก
      </h1>
      <p
        className="rise-in mt-1 font-display text-lg italic text-champagne"
        style={{ animationDelay: "140ms" }}
      >
        Ultimate Couple Game
      </p>
      <p
        className="rise-in mt-4 max-w-sm text-sm leading-relaxed text-muted"
        style={{ animationDelay: "180ms" }}
      >
        เริ่มจากคุยกอด แล้วค่อยร้อนขึ้นทีละขั้น จนถึงบนเตียง
        ดื่มครบแก้วถึงจะปลดขั้นถัดไป
      </p>
      <div
        className="rise-in mt-6 grid w-full grid-cols-4 gap-2"
        style={{ animationDelay: "200ms" }}
      >
        {HIGHLIGHTS.map((item) => (
          <div key={item.label} className="rounded-xl bg-elevated px-1 py-3">
            <p className="text-xl leading-none">{item.emoji}</p>
            <p className="mt-1 text-[11px] text-muted">{item.label}</p>
          </div>
        ))}
      </div>
      <p className="rise-in mt-5 text-xs text-subtle" style={{ animationDelay: "220ms" }}>
        สำหรับคู่รักอายุ 18 ปีขึ้นไปที่ยินยอมเล่นด้วยกัน
      </p>

      <div className="relative z-20 mt-8 flex w-full flex-col gap-3">
        <button
          type="button"
          onClick={start}
          className={cn(
            "glow-primary flex h-14 w-full items-center justify-center gap-2 rounded-xl",
            "bg-primary font-medium text-primary-fg",
            "touch-manipulation transition-transform duration-150 ease-out active:scale-[0.96]",
          )}
        >
          <Sparkles className="size-5" />
          เริ่มเกม
        </button>
        <button
          type="button"
          onClick={goToSetup}
          className="flex h-12 w-full items-center justify-center rounded-xl bg-elevated font-medium text-fg touch-manipulation transition-transform duration-150 ease-out active:scale-[0.96]"
        >
          ตั้งชื่อก่อน
        </button>
        {canResume ? (
          <button
            type="button"
            onClick={resume}
            className="flex h-12 w-full items-center justify-center rounded-xl bg-elevated font-medium text-fg touch-manipulation transition-transform duration-150 ease-out active:scale-[0.96]"
          >
            เล่นต่อ
          </button>
        ) : null}
      </div>
    </main>
  );
}
