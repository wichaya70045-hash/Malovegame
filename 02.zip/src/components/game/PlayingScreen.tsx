import { useEffect, useRef, useState } from "react";
import { Home, RotateCcw, Settings, Sparkles, Wine } from "lucide-react";
import { getDeckIds, fillNames } from "@/lib/game/content";
import { drinksToUnlock, isLevelUnlocked, useGameStore, useTotalDrinks } from "@/lib/game/store";
import {
  LEVELS,
  LEVEL_EMOJI,
  MODE_GROUPS,
  MODE_META,
  OPEN_LEVELS,
  SECRET_LEVEL,
  deckKey,
  type CardKind,
  type Mode,
  type ModeGroupId,
} from "@/lib/game/types";
import { cn } from "@/lib/utils";
import { CardTimer } from "./CardTimer";
import { ChaosPlay } from "./ChaosPlay";
import { DicePlay } from "./DicePlay";
import { DrunkWheel } from "./DrunkWheel";
import { PoseArt } from "./PoseArt";
import { PowerPlay } from "./PowerPlay";
import { SettingsModal } from "./SettingsModal";
import { TripleWheel } from "./TripleWheel";

const KIND_LABEL: Record<CardKind, string> = {
  truth: "💬 จริง",
  dare: "🔥 ท้า",
  never: "🚫 ไม่เคย",
  rather: "⚖️ เลือก",
  live: "🛏️ ภารกิจ",
  pose: "💋 ท่า",
  role: "🎭 สวมบท",
};

const MINI: Mode[] = ["wheel", "dice", "power", "tripleWheel", "chaos"];

export function PlayingScreen() {
  const players = useGameStore((s) => s.players);
  const currentPlayerIndex = useGameStore((s) => s.currentPlayerIndex);
  const mode = useGameStore((s) => s.mode);
  const selectedLevel = useGameStore((s) => s.selectedLevel);
  const unlockThresholds = useGameStore((s) => s.unlockThresholds);
  const currentCard = useGameStore((s) => s.currentCard);
  const deckEmpty = useGameStore((s) => s.deckEmpty);
  const decks = useGameStore((s) => s.decks);
  const justUnlocked = useGameStore((s) => s.justUnlocked);
  const selectMode = useGameStore((s) => s.selectMode);
  const selectLevel = useGameStore((s) => s.selectLevel);
  const drawCard = useGameStore((s) => s.drawCard);
  const reshuffleCurrent = useGameStore((s) => s.reshuffleCurrent);
  const drink = useGameStore((s) => s.drink);
  const skipWithDrink = useGameStore((s) => s.skipWithDrink);
  const completeCard = useGameStore((s) => s.completeCard);
  const nextWithoutDrink = useGameStore((s) => s.nextWithoutDrink);
  const resetGame = useGameStore((s) => s.resetGame);
  const goHome = useGameStore((s) => s.goHome);
  const dismissUnlock = useGameStore((s) => s.dismissUnlock);
  const bdsmOn = useGameStore((s) => s.bdsmOn);
  const totalDrinks = useTotalDrinks();
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [swapRoles, setSwapRoles] = useState(false);
  const levelStrip = useRef<HTMLDivElement>(null);

  const current = players[currentPlayerIndex];
  const partner = players[currentPlayerIndex === 0 ? 1 : 0];
  const say = (text: string) =>
    swapRoles
      ? fillNames(text, partner.name, current.name)
      : fillNames(text, current.name, partner.name);
  const key = deckKey(mode, selectedLevel);
  const remaining = decks[key]?.length ?? getDeckIds(mode, selectedLevel, bdsmOn).length;
  const levelMeta = LEVELS[selectedLevel - 1];
  const group = MODE_META[mode].group;
  const groupModes = MODE_GROUPS.find((g) => g.id === group)?.modes ?? [];
  const isMini = MINI.includes(mode);

  useEffect(() => {
    setSwapRoles(false);
  }, [currentCard?.id]);

  useEffect(() => {
    levelStrip.current
      ?.querySelector<HTMLElement>("[data-selected='true']")
      ?.scrollIntoView({ inline: "center", block: "nearest", behavior: "smooth" });
  }, [selectedLevel]);

  useEffect(() => {
    if (!menuOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setMenuOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [menuOpen]);

  useEffect(() => {
    if (!justUnlocked) return;
    const timer = window.setTimeout(() => dismissUnlock(), 2800);
    return () => window.clearTimeout(timer);
  }, [justUnlocked, dismissUnlock]);

  function pickGroup(id: ModeGroupId) {
    if (id === group) return;
    const first = MODE_GROUPS.find((g) => g.id === id)?.modes[0];
    if (first) selectMode(first);
  }

  return (
    <main className="relative z-10 mx-auto flex min-h-dvh w-full max-w-lg flex-col px-3 pb-28 pt-3 sm:px-4">
      <header className="mb-3 flex items-center justify-between gap-2">
        <button
          type="button"
          onClick={() => setMenuOpen(true)}
          className="flex size-11 items-center justify-center rounded-md text-muted hover:text-fg"
          aria-label="เมนู"
        >
          <Home className="size-5" />
        </button>
        <div className="text-center">
          <p className="font-display text-base font-semibold">เกมคู่รัก</p>
          <p className="text-xs text-subtle">
            ขั้น {selectedLevel === 9 ? "ลับ" : selectedLevel} · {levelMeta?.name}
          </p>
          <p className="text-[11px] text-champagne">{levelMeta?.tagline}</p>
        </div>
        <button
          type="button"
          onClick={() => setSettingsOpen(true)}
          className="flex size-11 items-center justify-center rounded-md text-muted hover:text-fg"
          aria-label="ตั้งค่า"
        >
          <Settings className="size-5" />
        </button>
      </header>

      <div className="mb-2 grid grid-cols-3 gap-1 rounded-xl bg-elevated p-1">
        {MODE_GROUPS.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => pickGroup(item.id)}
            className={cn(
              "flex h-11 items-center justify-center gap-1 rounded-lg text-sm font-medium",
              group === item.id ? "bg-primary text-primary-fg" : "text-muted",
            )}
          >
            <span>{item.emoji}</span>
            {item.label}
          </button>
        ))}
      </div>
      <div className="mb-3 flex gap-1">
        {groupModes.map((id) => {
          const meta = MODE_META[id];
          const locked =
            id === "roleplay" &&
            selectedLevel < 5 &&
            !isLevelUnlocked(5, totalDrinks, unlockThresholds);
          return (
            <button
              key={id}
              type="button"
              disabled={locked}
              onClick={() => selectMode(id)}
              className={cn(
                "flex h-11 min-w-0 flex-1 flex-col items-center justify-center rounded-lg px-1 text-center",
                mode === id
                  ? "bg-primary/20 text-fg ring-1 ring-primary"
                  : "bg-elevated text-muted",
                locked && "opacity-50",
              )}
            >
              <span className="text-base leading-none">{meta.emoji}</span>
              <span className="mt-0.5 text-[11px] font-medium">{locked ? "LV5+" : meta.short}</span>
            </button>
          );
        })}
      </div>

      <section className="glass mb-3 rounded-xl p-3">
        <div className="grid grid-cols-3 items-center gap-2">
          <PlayerChip player={players[0]} active={currentPlayerIndex === 0} />
          <div className="text-center">
            <p className="text-[10px] uppercase tracking-wider text-subtle">🍷 แก้วรวม</p>
            <p className="flex items-center justify-center gap-1 font-display text-2xl font-semibold tabular-nums text-champagne">
              <Wine className="size-4" />
              {totalDrinks}
            </p>
          </div>
          <PlayerChip player={players[1]} active={currentPlayerIndex === 1} />
        </div>
        <p className="mt-2 text-center text-sm">
          ตาของ{" "}
          <span className={current.gender === "male" ? "text-male" : "text-female"}>
            {current.gender === "male" ? "👨 " : "👩 "}
            {current.name}
          </span>
        </p>
      </section>

      <div ref={levelStrip} className="no-scrollbar mb-3 flex gap-1 overflow-x-auto pb-1">
        {OPEN_LEVELS.map((id) => {
          const unlocked = isLevelUnlocked(id, totalDrinks, unlockThresholds);
          const selected = selectedLevel === id;
          const need = drinksToUnlock(id, totalDrinks, unlockThresholds);
          return (
            <button
              key={id}
              type="button"
              disabled={!unlocked}
              data-selected={selected}
              aria-pressed={selected}
              onClick={() => selectLevel(id)}
              className={cn(
                "flex h-12 min-w-12 flex-col items-center justify-center rounded-lg px-2 transition-transform duration-150 active:scale-[0.96]",
                selected ? "bg-primary text-primary-fg glow-primary" : "bg-elevated text-fg",
                !unlocked && "opacity-50",
              )}
            >
              <span className="text-sm leading-none">{unlocked ? LEVEL_EMOJI[id] : "🔒"}</span>
              <span className="mt-0.5 text-[10px] font-medium">ขั้น {id}</span>
              {!unlocked ? <span className="text-[9px] opacity-80">อีก {need}</span> : null}
            </button>
          );
        })}
        {isLevelUnlocked(8, totalDrinks, unlockThresholds) ? (
          <button
            type="button"
            disabled={!isLevelUnlocked(SECRET_LEVEL, totalDrinks, unlockThresholds)}
            data-selected={selectedLevel === SECRET_LEVEL}
            aria-pressed={selectedLevel === SECRET_LEVEL}
            onClick={() => selectLevel(SECRET_LEVEL)}
            className={cn(
              "flex h-12 min-w-14 flex-col items-center justify-center rounded-lg px-2",
              selectedLevel === SECRET_LEVEL
                ? "bg-primary text-primary-fg glow-primary"
                : "bg-wine/40 text-champagne",
              !isLevelUnlocked(SECRET_LEVEL, totalDrinks, unlockThresholds) && "opacity-50",
            )}
          >
            <span className="text-sm leading-none">
              {isLevelUnlocked(SECRET_LEVEL, totalDrinks, unlockThresholds) ? "🔮" : "🔒"}
            </span>
            <span className="mt-0.5 text-[10px] font-medium">ลับ</span>
          </button>
        ) : null}
      </div>

      <section className="flex min-h-56 w-full flex-1 flex-col">
        {mode === "wheel" ? (
          <DrunkWheel key={selectedLevel} level={selectedLevel} />
        ) : mode === "dice" ? (
          <DicePlay key={selectedLevel} level={selectedLevel} />
        ) : mode === "power" ? (
          <PowerPlay key={selectedLevel} level={selectedLevel} />
        ) : mode === "tripleWheel" ? (
          <TripleWheel key={selectedLevel} level={selectedLevel} />
        ) : mode === "chaos" ? (
          <ChaosPlay key={selectedLevel} level={selectedLevel} />
        ) : deckEmpty ? (
          <div className="glass flex min-h-56 flex-1 flex-col items-center justify-center rounded-2xl p-6 text-center">
            <p className="font-display text-lg">ไพ่กองนี้หมดแล้ว</p>
            <p className="mt-1 text-sm text-muted">กดสับใหม่เพื่อจั่วต่อ</p>
            <button
              type="button"
              onClick={reshuffleCurrent}
              className="mt-4 flex h-12 items-center gap-2 rounded-xl bg-primary px-5 font-medium text-primary-fg"
            >
              <RotateCcw className="size-4" />
              สับไพ่ใหม่
            </button>
          </div>
        ) : currentCard ? (
          <article className="card-in glass flex min-h-56 flex-1 flex-col rounded-2xl p-5">
            <div className="mb-3 flex items-center justify-between">
              <span className="flex items-center gap-2">
                <span
                  className={cn(
                    "rounded-full px-3 py-1 text-xs font-medium",
                    currentCard.kind === "dare" ||
                      currentCard.kind === "live" ||
                      currentCard.kind === "pose"
                      ? "bg-primary/20 text-primary"
                      : "bg-champagne/15 text-champagne",
                  )}
                >
                  {KIND_LABEL[currentCard.kind]}
                </span>
                {currentCard.bdsm ? (
                  <span className="rounded-full bg-wine/30 px-2 py-1 text-xs font-medium text-champagne">
                    ⛓️ BDSM
                  </span>
                ) : null}
              </span>
              <span className="text-xs text-subtle">เหลือ {remaining} ใบ</span>
            </div>
            {currentCard.pose ? <PoseArt pose={currentCard.pose} /> : null}
            <p className="font-display text-xl leading-snug">{say(currentCard.text)}</p>
            {currentCard.kind === "pose" && currentCard.optionA ? (
              <p className="mt-2 text-sm leading-relaxed text-muted">{say(currentCard.optionA)}</p>
            ) : null}
            {currentCard.kind === "role" ? (
              <div className="mt-3 space-y-3">
                <div className="rounded-xl bg-elevated px-3 py-3">
                  <p className="text-[11px] uppercase tracking-wider text-champagne">บทบาท</p>
                  <p className="mt-1 text-sm leading-relaxed">{say(currentCard.optionA ?? "")}</p>
                  <button
                    type="button"
                    onClick={() => setSwapRoles((v) => !v)}
                    className="mt-2 text-xs font-medium text-primary"
                  >
                    สลับบท
                  </button>
                </div>
                <div className="rounded-xl bg-elevated px-3 py-3">
                  <p className="text-[11px] uppercase tracking-wider text-champagne">เล่นตามนี้</p>
                  <p className="mt-1 text-sm leading-relaxed">{say(currentCard.optionB ?? "")}</p>
                </div>
                <p className="text-xs text-muted">เล่นเป็นคนนั้นทั้งใบ มีคำหยุดเสมอ</p>
              </div>
            ) : null}
            {currentCard.kind === "live" ? (
              <p className="mt-3 text-sm text-muted">
                ทำบนเตียงตอนกำลังเย็ดหรือเล้าโลม ถ้าไม่ไหวดื่มได้
              </p>
            ) : null}
            {currentCard.bdsm ? (
              <p className="mt-2 text-xs text-champagne">มีคำหยุด ใช้ได้ทันที ถ้าไม่ไหวต้องเลิก</p>
            ) : null}
            {currentCard.kind === "rather" ? (
              <div className="mt-4 grid gap-2">
                <button
                  type="button"
                  onClick={completeCard}
                  className="min-h-12 rounded-lg bg-elevated px-3 py-3 text-left text-sm transition-transform duration-150 active:scale-[0.96]"
                >
                  <span className="text-xs text-champagne">ข้อ A</span>
                  <br />
                  {say(currentCard.optionA ?? "")}
                </button>
                <button
                  type="button"
                  onClick={completeCard}
                  className="min-h-12 rounded-lg bg-elevated px-3 py-3 text-left text-sm transition-transform duration-150 active:scale-[0.96]"
                >
                  <span className="text-xs text-champagne">ข้อ B</span>
                  <br />
                  {say(currentCard.optionB ?? "")}
                </button>
              </div>
            ) : null}
          </article>
        ) : (
          <button
            type="button"
            onClick={drawCard}
            className="pulse-glow glow-primary flex min-h-56 w-full flex-1 flex-col items-center justify-center rounded-2xl bg-elevated transition-transform duration-150 ease-out active:scale-[0.96] touch-manipulation"
          >
            <Sparkles className="mb-3 size-8 text-primary" />
            <span className="font-display text-2xl font-semibold">
              {mode === "inBed"
                ? "🛏️ จั่วภารกิจ"
                : mode === "positions"
                  ? "💋 สุ่มท่า"
                  : mode === "roleplay"
                    ? "🎭 จั่วบท"
                    : "🃏 จั่วการ์ด"}
            </span>
            <span className="mt-1 text-sm text-muted">
              {mode === "inBed"
                ? "เล่นบนเตียงตอนกำลังทำกัน"
                : mode === "positions"
                  ? "จั่วแล้วเย็ดท่านั้น"
                  : mode === "roleplay"
                    ? "สุ่มฉาก แล้วสวมบทเลย"
                    : `เหลือ ${remaining} ใบในกองนี้`}
            </span>
            {mode === "inBed" || mode === "positions" || mode === "roleplay" ? (
              <span className="mt-1 text-xs text-subtle">เหลือ {remaining} ใบในกองนี้</span>
            ) : null}
          </button>
        )}
      </section>

      {currentCard?.time && !isMini ? (
        <div className="mt-3">
          <CardTimer seconds={currentCard.time} cardId={currentCard.id} />
        </div>
      ) : null}

      {currentCard && !isMini ? (
        <div className="mt-3 grid gap-2">
          {currentCard.kind === "truth" ||
          currentCard.kind === "dare" ||
          currentCard.kind === "live" ||
          currentCard.kind === "pose" ? (
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={skipWithDrink}
                className="flex h-12 items-center justify-center rounded-xl bg-elevated font-medium"
              >
                {currentCard.kind === "live" || currentCard.kind === "pose"
                  ? "🍷 ไม่ไหว ดื่ม"
                  : "🍷 ไม่ทำ ดื่มแทน"}
              </button>
              <button
                type="button"
                onClick={completeCard}
                className="flex h-12 items-center justify-center rounded-xl bg-primary font-medium text-primary-fg"
              >
                {currentCard.kind === "live" || currentCard.kind === "pose" ? "ครบแล้ว" : "ทำแล้ว"}
              </button>
            </div>
          ) : null}
          {currentCard.kind === "never" ? (
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => drink(0)}
                className={cn(
                  "flex h-12 items-center justify-center rounded-xl bg-elevated px-1 text-sm font-medium",
                  players[0].gender === "male" ? "text-male" : "text-female",
                )}
              >
                {players[0].name} เคย
              </button>
              <button
                type="button"
                onClick={() => drink(1)}
                className={cn(
                  "flex h-12 items-center justify-center rounded-xl bg-elevated px-1 text-sm font-medium",
                  players[1].gender === "male" ? "text-male" : "text-female",
                )}
              >
                {players[1].name} เคย
              </button>
              <button
                type="button"
                onClick={nextWithoutDrink}
                className="flex h-12 items-center justify-center rounded-xl bg-primary text-sm font-medium text-primary-fg"
              >
                ใบถัดไป
              </button>
            </div>
          ) : null}
          {currentCard.kind === "rather" || currentCard.kind === "role" ? (
            <button
              type="button"
              onClick={completeCard}
              className="flex h-12 items-center justify-center rounded-xl bg-primary font-medium text-primary-fg"
            >
              ครบแล้ว
            </button>
          ) : null}
        </div>
      ) : null}

      {justUnlocked ? (
        <div className="pointer-events-none fixed inset-x-0 top-6 z-40 flex justify-center px-4">
          <div className="glass rounded-full px-4 py-2 text-sm text-champagne">
            ✨ ปลดล็อค {justUnlocked === 9 ? "ระดับลับ" : `LV ${justUnlocked}`}{" "}
            {LEVELS[justUnlocked - 1]?.name}
          </div>
        </div>
      ) : null}

      {menuOpen ? (
        <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center">
          <button
            type="button"
            className="absolute inset-0 bg-bg/70"
            aria-label="ปิดเมนู"
            onClick={() => setMenuOpen(false)}
          />
          <div
            role="dialog"
            aria-modal="true"
            aria-label="เมนูเกม"
            className="glass relative z-10 w-full max-w-sm space-y-2 rounded-t-2xl p-5 pb-[max(1.25rem,env(safe-area-inset-bottom))] sm:rounded-2xl"
          >
            <button
              type="button"
              onClick={() => {
                setMenuOpen(false);
                goHome();
              }}
              className="flex h-12 w-full items-center justify-center rounded-lg bg-elevated font-medium"
            >
              หน้าแรก
            </button>
            <button
              type="button"
              onClick={() => {
                setMenuOpen(false);
                resetGame();
              }}
              className="flex h-12 w-full items-center justify-center rounded-lg bg-elevated font-medium"
            >
              เริ่มใหม่
            </button>
            <button
              type="button"
              onClick={() => setMenuOpen(false)}
              className="flex h-12 w-full items-center justify-center rounded-lg bg-primary font-medium text-primary-fg"
            >
              เล่นต่อ
            </button>
          </div>
        </div>
      ) : null}

      <SettingsModal open={settingsOpen} onClose={() => setSettingsOpen(false)} />
    </main>
  );
}

function PlayerChip({
  player,
  active,
}: {
  player: { name: string; gender: "male" | "female"; drinks: number };
  active: boolean;
}) {
  return (
    <div className={cn("rounded-lg px-2 py-1 text-center", active && "bg-surface")}>
      <p
        className={cn(
          "truncate text-sm font-medium",
          player.gender === "male" ? "text-male" : "text-female",
        )}
      >
        {player.gender === "male" ? "👨 " : "👩 "}
        {player.name || (player.gender === "male" ? "เค้า" : "เธอ")}
      </p>
      <p className="text-xs tabular-nums text-muted">🍷 {player.drinks}</p>
    </div>
  );
}
