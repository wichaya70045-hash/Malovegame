import { useEffect, useRef, useState } from "react";
import { Wine } from "lucide-react";
import { fillNames } from "@/lib/game/content";
import { fisherYatesShuffle } from "@/lib/game/shuffle";
import { useGameStore } from "@/lib/game/store";
import { getWheelPool } from "@/lib/game/wheel";
import type { LevelId } from "@/lib/game/types";
import { cn } from "@/lib/utils";

export function DrunkWheel({ level }: { level: LevelId }) {
  const players = useGameStore((s) => s.players);
  const currentPlayerIndex = useGameStore((s) => s.currentPlayerIndex);
  const drink = useGameStore((s) => s.drink);
  const completeCard = useGameStore((s) => s.completeCard);
  const bdsmOn = useGameStore((s) => s.bdsmOn);
  const leftover = useRef<string[]>([]);
  const poolRef = useRef<string[]>([]);
  const spinLock = useRef(false);
  const timers = useRef<number[]>([]);
  useEffect(() => {
    const pending = timers.current;
    return () => pending.forEach((id) => window.clearTimeout(id));
  }, []);
  const [rotation, setRotation] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [text, setText] = useState<string | null>(null);
  const [left, setLeft] = useState(0);

  useEffect(() => {
    const next = getWheelPool(level, bdsmOn);
    poolRef.current = next;
    leftover.current = fisherYatesShuffle([...next]);
    setLeft(leftover.current.length);
    setText(null);
  }, [level, bdsmOn]);

  const current = players[currentPlayerIndex];
  const partner = players[currentPlayerIndex === 0 ? 1 : 0];
  const result = text ? fillNames(text, current.name, partner.name) : null;

  function spin() {
    if (spinLock.current) return;
    spinLock.current = true;
    setSpinning(true);
    setText(null);
    if (leftover.current.length === 0) {
      leftover.current = fisherYatesShuffle([...poolRef.current]);
    }
    const pick = leftover.current.shift() ?? poolRef.current[0]!;
    setLeft(leftover.current.length);
    const extraTurns = 4 + Math.floor(Math.random() * 3);
    const visual = Math.floor(Math.random() * 12);
    const slice = 30;
    const target = extraTurns * 360 + (360 - visual * slice - slice / 2);
    setRotation((r) => r + target);
    const done = window.setTimeout(() => {
      setText(pick);
      setSpinning(false);
      spinLock.current = false;
    }, 2800);
    timers.current.push(done);
  }

  return (
    <section className="glass flex min-h-56 flex-1 flex-col items-center rounded-2xl p-5">
      <p className="text-xs uppercase tracking-wider text-champagne">🎡 วงล้อเมา</p>
      <p className="mt-1 text-center text-sm text-muted">ปั่นแล้วทำตามเลย ห้ามคิดมาก</p>
      <p className="mt-1 text-xs text-subtle">เหลือ {left} คำสั่งในกองนี้</p>
      <div className="relative mt-4 size-56">
        <div className="absolute left-1/2 top-0 z-10 h-0 w-0 -translate-x-1/2 border-x-8 border-t-[18px] border-x-transparent border-t-primary" />
        <div
          className="size-56 rounded-full shadow-glow"
          style={{
            background:
              "conic-gradient(var(--color-primary) 0 30deg, var(--color-wine) 30deg 60deg, var(--color-elevated) 60deg 90deg, var(--color-primary) 90deg 120deg, var(--color-wine) 120deg 150deg, var(--color-elevated) 150deg 180deg, var(--color-primary) 180deg 210deg, var(--color-wine) 210deg 240deg, var(--color-elevated) 240deg 270deg, var(--color-primary) 270deg 300deg, var(--color-wine) 300deg 330deg, var(--color-elevated) 330deg 360deg)",
            transform: `rotate(${rotation}deg)`,
            transition: spinning ? "transform 2.8s cubic-bezier(0.12, 0.7, 0.12, 1)" : "none",
          }}
        />
        <button
          type="button"
          onClick={spin}
          disabled={spinning}
          className="absolute left-1/2 top-1/2 flex size-20 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-bg font-display text-lg font-semibold text-fg ring-2 ring-primary touch-manipulation"
        >
          {spinning ? "..." : "ปั่น"}
        </button>
      </div>
      <p className="mt-5 min-h-16 px-2 text-center font-display text-xl leading-snug">
        {spinning ? "รอวงล้อ..." : (result ?? "กดปั่นแล้วทำตามคำสั่ง")}
      </p>
      <div className="mt-4 grid w-full grid-cols-2 gap-2">
        <button
          type="button"
          onClick={() => drink(currentPlayerIndex)}
          className="flex h-12 items-center justify-center gap-1 rounded-xl bg-elevated font-medium touch-manipulation"
        >
          <Wine className="size-4" />
          ไม่ไหว ดื่ม
        </button>
        <button
          type="button"
          onClick={() => {
            completeCard();
            setText(null);
          }}
          className={cn(
            "flex h-12 items-center justify-center rounded-xl font-medium touch-manipulation",
            result ? "bg-primary text-primary-fg" : "bg-elevated text-muted",
          )}
        >
          ครบแล้ว
        </button>
      </div>
    </section>
  );
}
