import { useEffect, useRef, useState } from "react";
import { Pause, Play, RotateCcw } from "lucide-react";

export function CardTimer({ seconds, cardId }: { seconds: number; cardId: string }) {
  const [remainingMs, setRemainingMs] = useState(seconds * 1000);
  const [running, setRunning] = useState(false);
  const leftover = useRef(seconds * 1000);
  const endAt = useRef<number | null>(null);

  useEffect(() => {
    leftover.current = seconds * 1000;
    endAt.current = null;
    setRemainingMs(seconds * 1000);
    setRunning(false);
  }, [cardId, seconds]);

  useEffect(() => {
    if (!running) return;
    endAt.current = performance.now() + leftover.current;
    let raf = 0;
    const tick = (now: number) => {
      const left = Math.max(0, (endAt.current ?? now) - now);
      leftover.current = left;
      setRemainingMs(left);
      if (left <= 0) {
        setRunning(false);
        if (typeof navigator !== "undefined" && "vibrate" in navigator)
          navigator.vibrate?.([200, 100, 200]);
        return;
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [running]);

  const total = Math.max(1, seconds * 1000);
  const ratio = remainingMs / total;
  const display = Math.ceil(remainingMs / 1000);

  return (
    <div className="glass rounded-xl p-3">
      <div className="mb-2 flex items-center justify-between">
        <p className="text-xs font-medium uppercase tracking-wider text-subtle">จับเวลา</p>
        <p
          className={`font-display text-2xl tabular-nums ${remainingMs === 0 ? "text-primary" : "text-fg"}`}
        >
          {display >= 60
            ? `${Math.floor(display / 60)}:${String(display % 60).padStart(2, "0")}`
            : `${display}s`}
        </p>
      </div>
      <div className="mb-3 h-1.5 overflow-hidden rounded-full bg-elevated">
        <div
          className="h-full rounded-full bg-primary transition-[width] duration-100 ease-linear"
          style={{ width: `${Math.max(0, ratio * 100)}%` }}
        />
      </div>
      <div className="grid grid-cols-3 gap-2">
        <button
          type="button"
          onClick={() => remainingMs > 0 && setRunning(true)}
          disabled={running || remainingMs === 0}
          className="flex h-11 items-center justify-center gap-1 rounded-md bg-elevated text-sm disabled:opacity-40"
        >
          <Play className="size-4" />
          เริ่ม
        </button>
        <button
          type="button"
          onClick={() => setRunning(false)}
          disabled={!running}
          className="flex h-11 items-center justify-center gap-1 rounded-md bg-elevated text-sm disabled:opacity-40"
        >
          <Pause className="size-4" />
          หยุด
        </button>
        <button
          type="button"
          onClick={() => {
            leftover.current = seconds * 1000;
            endAt.current = null;
            setRemainingMs(seconds * 1000);
            setRunning(false);
          }}
          className="flex h-11 items-center justify-center gap-1 rounded-md bg-elevated text-sm"
        >
          <RotateCcw className="size-4" />
          รีเซ็ต
        </button>
      </div>
    </div>
  );
}
