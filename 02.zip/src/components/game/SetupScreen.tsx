import { useState } from "react";
import { ArrowLeft, Flame, Mars, Settings, Venus } from "lucide-react";
import { useGameStore } from "@/lib/game/store";
import { cn } from "@/lib/utils";
import { SettingsModal } from "./SettingsModal";

export function SetupScreen() {
  const players = useGameStore((s) => s.players);
  const setPlayerName = useGameStore((s) => s.setPlayerName);
  const setPlayerGender = useGameStore((s) => s.setPlayerGender);
  const setScreen = useGameStore((s) => s.setScreen);
  const startPlaying = useGameStore((s) => s.startPlaying);
  const heatStart = useGameStore((s) => s.heatStart);
  const setHeatStart = useGameStore((s) => s.setHeatStart);
  const bdsmOn = useGameStore((s) => s.bdsmOn);
  const setBdsmOn = useGameStore((s) => s.setBdsmOn);
  const [settingsOpen, setSettingsOpen] = useState(false);

  return (
    <main className="relative z-10 mx-auto flex min-h-dvh w-full max-w-lg flex-col px-4 py-6 pb-28 sm:px-6">
      <header className="mb-6 flex items-center justify-between">
        <button
          type="button"
          onClick={() => setScreen("home")}
          className="flex size-11 items-center justify-center rounded-md text-muted transition-transform duration-150 ease-out hover:text-fg active:scale-[0.96]"
          aria-label="กลับหน้าแรก"
        >
          <ArrowLeft className="size-5" />
        </button>
        <h1 className="font-display text-xl font-semibold">ตั้งค่าผู้เล่น</h1>
        <button
          type="button"
          onClick={() => setSettingsOpen(true)}
          className="flex size-11 items-center justify-center rounded-md text-muted transition-transform duration-150 ease-out hover:text-fg active:scale-[0.96]"
          aria-label="ตั้งค่า"
        >
          <Settings className="size-5" />
        </button>
      </header>

      <div className="grid gap-4 sm:grid-cols-2">
        {([0, 1] as const).map((index) => {
          const player = players[index];
          return (
            <section key={index} className="glass rounded-xl p-4">
              <p className="mb-3 text-xs font-medium uppercase tracking-wider text-subtle">
                ผู้เล่น {index + 1}
              </p>
              <label className="block text-sm text-muted">
                ชื่อผู้เล่น {index + 1}
                <input
                  id={`player-${index}-name`}
                  value={player.name}
                  onChange={(e) => setPlayerName(index, e.target.value)}
                  placeholder={index === 0 ? "เค้า" : "เธอ"}
                  maxLength={16}
                  className={cn(
                    "mt-1 h-12 w-full rounded-lg bg-elevated px-3 text-base outline-none",
                    "ring-1 ring-border focus:ring-2 focus:ring-primary",
                    player.gender === "male" ? "text-male" : "text-female",
                  )}
                />
              </label>
              <div className="mt-3 grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setPlayerGender(index, "male")}
                  className={cn(
                    "flex h-12 items-center justify-center gap-2 rounded-lg text-sm font-medium transition-transform duration-150 ease-out active:scale-[0.96]",
                    player.gender === "male"
                      ? "bg-male/20 text-male ring-1 ring-male"
                      : "bg-elevated text-muted",
                  )}
                >
                  <Mars className="size-4" />
                  ♂️ ชาย
                </button>
                <button
                  type="button"
                  onClick={() => setPlayerGender(index, "female")}
                  className={cn(
                    "flex h-12 items-center justify-center gap-2 rounded-lg text-sm font-medium transition-transform duration-150 ease-out active:scale-[0.96]",
                    player.gender === "female"
                      ? "bg-female/20 text-female ring-1 ring-female"
                      : "bg-elevated text-muted",
                  )}
                >
                  <Venus className="size-4" />
                  ♀️ หญิง
                </button>
              </div>
            </section>
          );
        })}
      </div>

      <button
        type="button"
        onClick={() => setHeatStart(!heatStart)}
        className={cn(
          "mt-5 flex min-h-14 w-full items-center justify-between rounded-xl px-4 text-left transition-transform duration-150 ease-out active:scale-[0.96]",
          heatStart ? "bg-primary/20 ring-1 ring-primary" : "bg-elevated",
        )}
      >
        <span>
          <span className="block text-sm font-medium">🔥 โหมดเดือด</span>
          <span className="block text-xs text-muted">
            {heatStart ? "ข้ามไปขั้นร้อน (ปากและมือ) ขั้นเย็ดยังต้องดื่มปลด" : "เริ่มขั้นหวาน แล้วร้อนขึ้นตามแก้ว"}
          </span>
        </span>
        <span
          className={cn(
            "relative h-6 w-11 shrink-0 rounded-full transition-colors",
            heatStart ? "bg-primary" : "bg-subtle",
          )}
        >
          <span
            className={cn(
              "absolute top-0.5 size-5 rounded-full bg-fg transition-transform",
              heatStart ? "translate-x-5" : "translate-x-0.5",
            )}
          />
        </span>
      </button>

      <button
        type="button"
        onClick={() => setBdsmOn(!bdsmOn)}
        className={cn(
          "mt-3 flex min-h-14 w-full items-center justify-between rounded-xl px-4 text-left transition-transform duration-150 ease-out active:scale-[0.96]",
          bdsmOn ? "bg-primary/20 ring-1 ring-primary" : "bg-elevated",
        )}
      >
        <span>
          <span className="block text-sm font-medium">⛓️ BDSM</span>
          <span className="block text-xs text-muted">
            {bdsmOn
              ? "มัด ปิดตา สั่ง ตบก้น — มีคำหยุดเสมอ"
              : "ปิดไว้ ไพ่จะไม่สุ่มข้อ BDSM"}
          </span>
        </span>
        <span
          className={cn(
            "relative h-6 w-11 shrink-0 rounded-full transition-colors",
            bdsmOn ? "bg-primary" : "bg-subtle",
          )}
        >
          <span
            className={cn(
              "absolute top-0.5 size-5 rounded-full bg-fg transition-transform",
              bdsmOn ? "translate-x-5" : "translate-x-0.5",
            )}
          />
        </span>
      </button>

      <p className="mt-4 text-center text-sm text-subtle">
        {heatStart
          ? "เริ่มที่ขั้นปากและมือ ขั้นเย็ดต้องดื่มปลดต่อ"
          : "เริ่มขั้นหวาน ดื่มครบแก้วแล้วค่อยร้อนขึ้น"}
      </p>

      <button
        type="button"
        onClick={startPlaying}
        className="glow-primary relative z-20 mt-4 mb-4 flex h-14 w-full items-center justify-center gap-2 rounded-xl bg-primary font-medium text-primary-fg touch-manipulation transition-transform duration-150 ease-out active:scale-[0.96]"
      >
        <Flame className="size-5" />
        เริ่มลุย
      </button>

      <SettingsModal open={settingsOpen} onClose={() => setSettingsOpen(false)} />
    </main>
  );
}
