import { useEffect } from "react";
import { useGameStore } from "@/lib/game/store";
import { HomeScreen } from "./HomeScreen";
import { PlayingScreen } from "./PlayingScreen";
import { SetupScreen } from "./SetupScreen";

export function App() {
  const hydrate = useGameStore((s) => s.hydrate);
  const screen = useGameStore((s) => s.screen);
  const hydrated = useGameStore((s) => s.hydrated);

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  return (
    <div className="atmosphere flex min-h-dvh w-full flex-col text-fg">
      {hydrated && screen === "home" ? <HomeScreen /> : null}
      {hydrated && screen === "setup" ? <SetupScreen /> : null}
      {hydrated && screen === "playing" ? <PlayingScreen /> : null}
    </div>
  );
}
