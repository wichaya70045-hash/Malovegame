import type { PoseId } from "@/lib/game/types";

type Pt = [number, number];
const GOLD = "var(--color-champagne)";
const PINK = "var(--color-primary)";
const FURN = "var(--color-subtle)";
const INK = "var(--color-bg)";

function Bone({ a, b, r, color }: { a: Pt; b: Pt; r: number; color: string }) {
  const dx = b[0] - a[0];
  const dy = b[1] - a[1];
  const len = Math.hypot(dx, dy) || 1;
  const ang = (Math.atan2(dy, dx) * 180) / Math.PI;
  const mx = (a[0] + b[0]) / 2;
  const my = (a[1] + b[1]) / 2;
  return (
    <ellipse
      cx={mx}
      cy={my}
      rx={len / 2 + 1}
      ry={r}
      transform={`rotate(${ang} ${mx} ${my})`}
      fill={color}
    />
  );
}

function Person({
  head,
  face,
  hip,
  knees,
  feet,
  hands,
  color,
  tag,
  tagAt,
  hair,
  blindfold,
}: {
  head: Pt;
  face: "l" | "r";
  hip: Pt;
  knees: [Pt, Pt];
  feet: [Pt, Pt];
  hands: [Pt, Pt];
  color: string;
  tag: string;
  tagAt: Pt;
  hair?: boolean;
  blindfold?: boolean;
}) {
  const withHair = hair ?? color === GOLD;
  const shoulder: Pt = [
    head[0] + (hip[0] - head[0]) * 0.28,
    head[1] + (hip[1] - head[1]) * 0.28,
  ];
  return (
    <g>
      <Bone a={shoulder} b={hip} r={12} color={color} />
      <circle cx={hip[0]} cy={hip[1]} r={13} fill={color} />
      <Bone a={hip} b={knees[0]} r={9} color={color} />
      <Bone a={knees[0]} b={feet[0]} r={7} color={color} />
      <Bone a={hip} b={knees[1]} r={9} color={color} />
      <Bone a={knees[1]} b={feet[1]} r={7} color={color} />
      <Bone a={shoulder} b={hands[0]} r={6} color={color} />
      <Bone a={shoulder} b={hands[1]} r={6} color={color} />
      {withHair ? (
        <ellipse
          cx={head[0] + (face === "r" ? -7 : 7)}
          cy={head[1] - 7}
          rx="10"
          ry="8"
          fill={color}
        />
      ) : null}
      <circle cx={head[0]} cy={head[1]} r={12} fill={color} />
      <circle
        cx={head[0] + (face === "r" ? 5 : -5)}
        cy={head[1] + 1}
        r={3.2}
        fill="#fff"
      />
      <circle
        cx={head[0] + (face === "r" ? 6 : -6)}
        cy={head[1] + 1}
        r={1.6}
        fill={INK}
      />
      {blindfold ? (
        <rect
          x={head[0] - 13}
          y={head[1] - 4}
          width="26"
          height="8"
          rx="3"
          fill={INK}
        />
      ) : null}
      <text
        x={tagAt[0]}
        y={tagAt[1]}
        fill={color}
        fontSize="12"
        fontWeight="700"
        fontFamily="Sarabun, sans-serif"
      >
        {tag}
      </text>
    </g>
  );
}

function Bed() {
  return (
    <>
      <rect x="14" y="122" width="232" height="22" rx="6" fill={FURN} />
      <rect x="20" y="108" width="48" height="22" rx="6" fill={FURN} opacity="0.7" />
      <rect x="28" y="144" width="10" height="12" fill={FURN} />
      <rect x="222" y="144" width="10" height="12" fill={FURN} />
    </>
  );
}

function Wall() {
  return <rect x="14" y="16" width="14" height="126" rx="3" fill={FURN} />;
}

function Chair() {
  return (
    <path
      d="M78 142 V92 H138 V142 M78 92 H58"
      fill="none"
      stroke={FURN}
      strokeWidth="8"
      strokeLinejoin="round"
      strokeLinecap="round"
    />
  );
}

const HINT: Record<PoseId, string> = {
  cuddle: "ยืนชิด กอดจากหลัง",
  lap: "ตัวชมพูนั่งบนตักตัวทอง",
  wallKiss: "ยืนพิงผนัง จูบกัน",
  grind: "นั่งคร่อมขย่ม",
  missionary: "ตัวทองนอนหงาย · ตัวชมพูทับบน",
  cowgirl: "ตัวทองนอน · ตัวชมพูนั่งคร่อมหันหน้า",
  reverse: "ตัวทองนอน · ตัวชมพูนั่งคร่อมหันหลัง",
  doggy: "ตัวทองคุกเข่าสี่ขา · ตัวชมพูคุกเข่าด้านหลัง",
  spoon: "นอนตะแคง ตัวชมพูกอดจากหลัง",
  wall: "ตัวทองพิงผนัง · ตัวชมพูยืนเย็ดจากหลัง",
  chair: "ตัวทองนั่งเก้าอี้ · ตัวชมพูคร่อม",
  standing: "ยืนชิด ตัวชมพูอยู่หน้าหรืออุ้ม",
  lotus: "นั่งกอด หน้าเข้าหากัน",
  legsUp: "ตัวทองนอนยกขา · ตัวชมพูอยู่ระหว่างขา",
  oral: "ตัวชมพูคุกเข่าใช้ปาก · ตัวทองนั่งหรือยืน",
  sixtyNine: "นอนสลับหัวท้าย ใช้ปากพร้อมกัน",
  prone: "ตัวทองนอนคว่ำ · ตัวชมพูทับจากหลัง",
  edge: "ตัวทองห้อยขอบเตียง · ตัวชมพูยืนใส่",
  facesit: "ตัวทองนอน · ตัวชมพูนั่งบนหน้า",
  bentOver: "ตัวทองก้มพิงเตียง · ตัวชมพูยืนหลัง",
  kneeling: "ทั้งคู่คุกเข่า หน้าเข้าหากัน",
  seatedBack: "ตัวทองนั่ง · ตัวชมพูนั่งหลังในตัก",
  carry: "ตัวชมพูยืนอุ้ม · ขาสองข้างของตัวทองโอบเอว",
  squat: "ตัวทองนอน · ตัวชมพอย่อเข่าขย่ม",
  table: "ตัวทองนอนบนโต๊ะ · ตัวชมพูยืนใส่",
  frog: "ตัวทองนอนแยกเข่า · ตัวชมพูคุกเข่าใส่",
  press: "ตัวทองนอนพับขาชิดอก · ตัวชมพูกดลง",
  sideFace: "นอนตะแคง หน้าเข้าหากัน",
  bound: "ตัวทองถูกมัดมือ · ตัวชมพูเป็นคนสั่ง",
  spank: "ตัวทองก้ม · ตัวชมพูตบก้น",
  blind: "ตัวทองถูกปิดตา · ตัวชมพูจูงมือ",
};

function Scene({ pose }: { pose: PoseId }) {
  switch (pose) {
    case "cuddle":
      return (
        <>
          <Person
            color={GOLD}
            head={[96, 42]}
            face="r"
            hip={[100, 92]}
            knees={[[90, 142], [112, 142]]}
            feet={[[86, 142], [118, 142]]}
            hands={[[128, 80], [88, 88]]}
            tag="ยืน"
            tagAt={[78, 28]}
          />
          <Person
            color={PINK}
            head={[132, 40]}
            face="l"
            hip={[128, 92]}
            knees={[[118, 142], [140, 142]]}
            feet={[[114, 142], [146, 142]]}
            hands={[[104, 78], [140, 86]]}
            tag="กอดหลัง"
            tagAt={[138, 26]}
          />
        </>
      );
    case "lap":
      return (
        <>
          <Bed />
          <Person
            color={GOLD}
            head={[78, 50]}
            face="r"
            hip={[118, 108]}
            knees={[[108, 142], [150, 142]]}
            feet={[[100, 142], [162, 142]]}
            hands={[[130, 86], [96, 90]]}
            tag="นั่ง"
            tagAt={[54, 42]}
          />
          <Person
            color={PINK}
            head={[126, 28]}
            face="l"
            hip={[128, 84]}
            knees={[[112, 128], [148, 128]]}
            feet={[[106, 142], [156, 142]]}
            hands={[[148, 70], [110, 72]]}
            tag="นั่งตัก"
            tagAt={[138, 20]}
          />
        </>
      );
    case "wallKiss":
      return (
        <>
          <Wall />
          <Person
            color={GOLD}
            head={[58, 40]}
            face="r"
            hip={[64, 92]}
            knees={[[56, 142], [76, 142]]}
            feet={[[52, 142], [82, 142]]}
            hands={[[92, 78], [54, 70]]}
            tag="พิงผนัง"
            tagAt={[44, 26]}
          />
          <Person
            color={PINK}
            head={[102, 38]}
            face="l"
            hip={[96, 92]}
            knees={[[86, 142], [108, 142]]}
            feet={[[82, 142], [114, 142]]}
            hands={[[70, 74], [108, 80]]}
            tag="จูบ"
            tagAt={[108, 26]}
          />
        </>
      );
    case "grind":
      return (
        <>
          <Bed />
          <Person
            color={GOLD}
            head={[70, 62]}
            face="r"
            hip={[128, 108]}
            knees={[[118, 142], [158, 142]]}
            feet={[[110, 142], [170, 142]]}
            hands={[[96, 96], [148, 100]]}
            tag="นอน/นั่ง"
            tagAt={[40, 54]}
          />
          <Person
            color={PINK}
            head={[130, 24]}
            face="l"
            hip={[132, 82]}
            knees={[[112, 128], [154, 128]]}
            feet={[[106, 142], [160, 142]]}
            hands={[[112, 70], [154, 70]]}
            tag="คร่อม"
            tagAt={[142, 18]}
          />
        </>
      );
    case "missionary":
      return (
        <>
          <Bed />
          <Person
            color={GOLD}
            head={[40, 58]}
            face="r"
            hip={[128, 96]}
            knees={[[176, 54], [186, 72]]}
            feet={[[198, 36], [210, 52]]}
            hands={[[70, 88], [58, 100]]}
            tag="นอนหงาย"
            tagAt={[22, 44]}
          />
          <Person
            color={PINK}
            head={[86, 28]}
            face="l"
            hip={[132, 78]}
            knees={[[118, 126], [150, 126]]}
            feet={[[110, 126], [158, 126]]}
            hands={[[70, 62], [108, 52]]}
            tag="ทับบน"
            tagAt={[96, 18]}
          />
        </>
      );
    case "cowgirl":
      return (
        <>
          <Bed />
          <Person
            color={GOLD}
            head={[38, 70]}
            face="r"
            hip={[130, 100]}
            knees={[[178, 88], [186, 108]]}
            feet={[[210, 80], [216, 104]]}
            hands={[[64, 96], [58, 108]]}
            tag="นอนหงาย"
            tagAt={[20, 58]}
          />
          <Person
            color={PINK}
            head={[128, 22]}
            face="l"
            hip={[130, 82]}
            knees={[[108, 126], [154, 126]]}
            feet={[[98, 126], [166, 126]]}
            hands={[[108, 64], [152, 64]]}
            tag="นั่งคร่อม"
            tagAt={[142, 18]}
          />
        </>
      );
    case "reverse":
      return (
        <>
          <Bed />
          <Person
            color={GOLD}
            head={[38, 72]}
            face="r"
            hip={[128, 100]}
            knees={[[176, 90], [184, 108]]}
            feet={[[208, 82], [214, 106]]}
            hands={[[62, 98], [56, 110]]}
            tag="นอนหงาย"
            tagAt={[20, 60]}
          />
          <Person
            color={PINK}
            head={[156, 22]}
            face="r"
            hip={[132, 82]}
            knees={[[110, 126], [156, 126]]}
            feet={[[100, 126], [168, 126]]}
            hands={[[114, 64], [154, 58]]}
            tag="หันหลัง"
            tagAt={[164, 18]}
          />
        </>
      );
    case "doggy":
      return (
        <>
          <Bed />
          <Person
            color={GOLD}
            head={[44, 70]}
            face="l"
            hip={[128, 88]}
            knees={[[116, 126], [140, 126]]}
            feet={[[100, 126], [128, 126]]}
            hands={[[38, 126], [56, 126]]}
            tag="สี่ขา"
            tagAt={[22, 58]}
          />
          <Person
            color={PINK}
            head={[204, 40]}
            face="l"
            hip={[168, 86]}
            knees={[[160, 126], [184, 126]]}
            feet={[[148, 126], [176, 126]]}
            hands={[[126, 80], [140, 76]]}
            tag="ด้านหลัง"
            tagAt={[186, 28]}
          />
        </>
      );
    case "spoon":
      return (
        <>
          <Bed />
          <Person
            color={GOLD}
            head={[40, 62]}
            face="r"
            hip={[120, 92]}
            knees={[[168, 108], [176, 120]]}
            feet={[[198, 112], [206, 126]]}
            hands={[[90, 88], [78, 100]]}
            tag="นอนตะแคง"
            tagAt={[18, 48]}
          />
          <Person
            color={PINK}
            head={[58, 40]}
            face="r"
            hip={[132, 76]}
            knees={[[176, 92], [184, 104]]}
            feet={[[206, 96], [214, 110]]}
            hands={[[108, 72], [96, 84]]}
            tag="กอดหลัง"
            tagAt={[70, 26]}
          />
        </>
      );
    case "wall":
      return (
        <>
          <Wall />
          <Person
            color={GOLD}
            head={[54, 36]}
            face="l"
            hip={[68, 92]}
            knees={[[58, 142], [80, 142]]}
            feet={[[54, 142], [86, 142]]}
            hands={[[40, 70], [48, 58]]}
            tag="พิงผนัง"
            tagAt={[40, 22]}
          />
          <Person
            color={PINK}
            head={[118, 34]}
            face="l"
            hip={[98, 90]}
            knees={[[90, 142], [112, 142]]}
            feet={[[86, 142], [118, 142]]}
            hands={[[72, 78], [86, 70]]}
            tag="จากหลัง"
            tagAt={[122, 22]}
          />
        </>
      );
    case "chair":
      return (
        <>
          <Chair />
          <Person
            color={GOLD}
            head={[96, 40]}
            face="r"
            hip={[112, 92]}
            knees={[[108, 142], [150, 128]]}
            feet={[[104, 142], [168, 142]]}
            hands={[[128, 78], [90, 80]]}
            tag="นั่ง"
            tagAt={[72, 30]}
          />
          <Person
            color={PINK}
            head={[132, 18]}
            face="l"
            hip={[122, 78]}
            knees={[[108, 124], [146, 124]]}
            feet={[[102, 142], [156, 142]]}
            hands={[[104, 62], [146, 60]]}
            tag="คร่อม"
            tagAt={[142, 14]}
          />
        </>
      );
    case "standing":
      return (
        <>
          <Person
            color={GOLD}
            head={[92, 32]}
            face="r"
            hip={[96, 88]}
            knees={[[88, 142], [108, 142]]}
            feet={[[84, 142], [114, 142]]}
            hands={[[118, 70], [90, 80]]}
            tag="ยืน"
            tagAt={[70, 22]}
          />
          <Person
            color={PINK}
            head={[134, 28]}
            face="l"
            hip={[128, 86]}
            knees={[[118, 142], [140, 142]]}
            feet={[[114, 142], [146, 142]]}
            hands={[[104, 64], [138, 72]]}
            tag="ชิด/อุ้ม"
            tagAt={[140, 18]}
          />
        </>
      );
    case "lotus":
      return (
        <>
          <Bed />
          <Person
            color={GOLD}
            head={[86, 40]}
            face="r"
            hip={[112, 100]}
            knees={[[78, 118], [150, 118]]}
            feet={[[96, 108], [132, 108]]}
            hands={[[136, 72], [100, 78]]}
            tag="นั่ง"
            tagAt={[62, 30]}
          />
          <Person
            color={PINK}
            head={[156, 38]}
            face="l"
            hip={[128, 98]}
            knees={[[98, 120], [170, 118]]}
            feet={[[116, 108], [146, 108]]}
            hands={[[108, 70], [148, 76]]}
            tag="กอดหน้า"
            tagAt={[160, 26]}
          />
        </>
      );
    case "legsUp":
      return (
        <>
          <Bed />
          <Person
            color={GOLD}
            head={[38, 78]}
            face="r"
            hip={[124, 96]}
            knees={[[168, 48], [176, 64]]}
            feet={[[186, 24], [198, 40]]}
            hands={[[64, 96], [54, 108]]}
            tag="ยกขา"
            tagAt={[20, 66]}
          />
          <Person
            color={PINK}
            head={[92, 28]}
            face="l"
            hip={[128, 78]}
            knees={[[116, 126], [148, 126]]}
            feet={[[108, 126], [156, 126]]}
            hands={[[150, 50], [108, 52]]}
            tag="ระหว่างขา"
            tagAt={[100, 18]}
          />
        </>
      );
    case "oral":
      return (
        <>
          <Bed />
          <Person
            color={GOLD}
            head={[168, 28]}
            face="l"
            hip={[160, 86]}
            knees={[[150, 142], [174, 142]]}
            feet={[[146, 142], [180, 142]]}
            hands={[[150, 70], [172, 64]]}
            tag="นั่ง/ยืน"
            tagAt={[174, 20]}
          />
          <Person
            color={PINK}
            head={[78, 88]}
            face="r"
            hip={[96, 108]}
            knees={[[86, 142], [112, 142]]}
            feet={[[78, 142], [120, 142]]}
            hands={[[128, 92], [118, 104]]}
            tag="คุกเข่า"
            tagAt={[48, 80]}
          />
        </>
      );
    case "sixtyNine":
      return (
        <>
          <Bed />
          <Person
            color={GOLD}
            head={[44, 44]}
            face="r"
            hip={[128, 68]}
            knees={[[176, 78], [186, 90]]}
            feet={[[204, 82], [214, 96]]}
            hands={[[96, 86], [88, 98]]}
            tag="หัวซ้าย"
            tagAt={[22, 32]}
          />
          <Person
            color={PINK}
            head={[208, 108]}
            face="l"
            hip={[124, 90]}
            knees={[[76, 80], [66, 92]]}
            feet={[[50, 84], [40, 98]]}
            hands={[[156, 78], [164, 68]]}
            tag="หัวขวา"
            tagAt={[186, 142]}
          />
        </>
      );
    case "prone":
      return (
        <>
          <Bed />
          <Person
            color={GOLD}
            head={[40, 78]}
            face="l"
            hip={[130, 90]}
            knees={[[176, 96], [184, 108]]}
            feet={[[206, 100], [214, 112]]}
            hands={[[48, 104], [36, 108]]}
            tag="นอนคว่ำ"
            tagAt={[20, 66]}
          />
          <Person
            color={PINK}
            head={[176, 32]}
            face="l"
            hip={[140, 78]}
            knees={[[128, 126], [156, 126]]}
            feet={[[118, 126], [166, 126]]}
            hands={[[112, 76], [126, 70]]}
            tag="ทับหลัง"
            tagAt={[168, 22]}
          />
        </>
      );
    case "edge":
      return (
        <>
          <rect x="16" y="96" width="132" height="16" rx="5" fill={FURN} />
          <Person
            color={GOLD}
            head={[36, 52]}
            face="r"
            hip={[128, 88]}
            knees={[[156, 118], [164, 132]]}
            feet={[[168, 148], [176, 148]]}
            hands={[[64, 78], [52, 88]]}
            tag="ห้อยขอบ"
            tagAt={[18, 40]}
          />
          <Person
            color={PINK}
            head={[196, 28]}
            face="l"
            hip={[170, 82]}
            knees={[[160, 142], [184, 142]]}
            feet={[[156, 142], [190, 142]]}
            hands={[[136, 80], [148, 74]]}
            tag="ยืนใส่"
            tagAt={[186, 18]}
          />
        </>
      );
    case "facesit":
      return (
        <>
          <Bed />
          <Person
            color={GOLD}
            head={[58, 86]}
            face="r"
            hip={[150, 96]}
            knees={[[196, 88], [204, 104]]}
            feet={[[220, 80], [226, 100]]}
            hands={[[90, 108], [80, 116]]}
            tag="นอน"
            tagAt={[28, 76]}
          />
          <Person
            color={PINK}
            head={[62, 24]}
            face="r"
            hip={[64, 70]}
            knees={[[48, 126], [84, 126]]}
            feet={[[40, 126], [94, 126]]}
            hands={[[48, 56], [84, 56]]}
            tag="นั่งบนหน้า"
            tagAt={[78, 18]}
          />
        </>
      );
    case "bentOver":
      return (
        <>
          <rect x="16" y="104" width="150" height="16" rx="5" fill={FURN} />
          <Person
            color={GOLD}
            head={[40, 58]}
            face="l"
            hip={[128, 92]}
            knees={[[122, 142], [142, 142]]}
            feet={[[118, 142], [148, 142]]}
            hands={[[36, 104], [52, 104]]}
            tag="ก้มพิง"
            tagAt={[22, 44]}
          />
          <Person
            color={PINK}
            head={[196, 32]}
            face="l"
            hip={[164, 86]}
            knees={[[154, 142], [178, 142]]}
            feet={[[150, 142], [184, 142]]}
            hands={[[130, 84], [144, 78]]}
            tag="ยืนหลัง"
            tagAt={[178, 20]}
          />
        </>
      );
    case "kneeling":
      return (
        <>
          <Bed />
          <Person
            color={GOLD}
            head={[86, 36]}
            face="r"
            hip={[92, 92]}
            knees={[[82, 126], [106, 126]]}
            feet={[[72, 126], [96, 126]]}
            hands={[[120, 70], [88, 78]]}
            tag="คุกเข่า"
            tagAt={[58, 26]}
          />
          <Person
            color={PINK}
            head={[156, 34]}
            face="l"
            hip={[148, 92]}
            knees={[[136, 126], [160, 126]]}
            feet={[[128, 126], [152, 126]]}
            hands={[[122, 70], [154, 78]]}
            tag="คุกเข่า"
            tagAt={[162, 24]}
          />
        </>
      );
    case "seatedBack":
      return (
        <>
          <Bed />
          <Person
            color={GOLD}
            head={[118, 40]}
            face="r"
            hip={[128, 100]}
            knees={[[150, 142], [170, 128]]}
            feet={[[168, 142], [190, 142]]}
            hands={[[148, 80], [112, 86]]}
            tag="นั่ง"
            tagAt={[96, 30]}
          />
          <Person
            color={PINK}
            head={[86, 28]}
            face="r"
            hip={[108, 88]}
            knees={[[100, 142], [124, 128]]}
            feet={[[118, 142], [140, 142]]}
            hands={[[128, 70], [96, 74]]}
            tag="นั่งหลัง"
            tagAt={[58, 20]}
          />
        </>
      );
    case "carry":
      return (
        <>
          <Person
            color={PINK}
            head={[118, 24]}
            face="l"
            hip={[120, 86]}
            knees={[[108, 142], [134, 142]]}
            feet={[[104, 142], [140, 142]]}
            hands={[[148, 70], [92, 70]]}
            tag="ยืนอุ้ม"
            tagAt={[128, 16]}
          />
          <Person
            color={GOLD}
            head={[86, 36]}
            face="r"
            hip={[132, 78]}
            knees={[[158, 58], [168, 70]]}
            feet={[[176, 44], [186, 56]]}
            hands={[[118, 48], [102, 56]]}
            tag="โอบเอว"
            tagAt={[48, 28]}
          />
        </>
      );
    case "squat":
      return (
        <>
          <Bed />
          <Person
            color={GOLD}
            head={[40, 72]}
            face="r"
            hip={[128, 100]}
            knees={[[176, 90], [184, 108]]}
            feet={[[206, 84], [214, 106]]}
            hands={[[64, 98], [56, 110]]}
            tag="นอนหงาย"
            tagAt={[20, 60]}
          />
          <Person
            color={PINK}
            head={[130, 30]}
            face="l"
            hip={[132, 92]}
            knees={[[108, 126], [156, 126]]}
            feet={[[100, 126], [164, 126]]}
            hands={[[110, 70], [154, 70]]}
            tag="ย่อขย่ม"
            tagAt={[146, 22]}
          />
        </>
      );
    case "table":
      return (
        <>
          <rect x="28" y="88" width="150" height="18" rx="4" fill={FURN} />
          <rect x="36" y="106" width="10" height="36" fill={FURN} />
          <rect x="160" y="106" width="10" height="36" fill={FURN} />
          <Person
            color={GOLD}
            head={[44, 48]}
            face="r"
            hip={[128, 78]}
            knees={[[168, 70], [176, 84]]}
            feet={[[196, 64], [204, 80]]}
            hands={[[70, 72], [58, 80]]}
            tag="นอนบนโต๊ะ"
            tagAt={[20, 36]}
          />
          <Person
            color={PINK}
            head={[198, 24]}
            face="l"
            hip={[172, 76]}
            knees={[[162, 142], [186, 142]]}
            feet={[[158, 142], [192, 142]]}
            hands={[[140, 74], [152, 68]]}
            tag="ยืนใส่"
            tagAt={[186, 16]}
          />
        </>
      );
    case "frog":
      return (
        <>
          <Bed />
          <Person
            color={GOLD}
            head={[42, 70]}
            face="r"
            hip={[120, 96]}
            knees={[[92, 54], [156, 54]]}
            feet={[[78, 36], [172, 36]]}
            hands={[[64, 96], [54, 108]]}
            tag="แยกเข่า"
            tagAt={[22, 58]}
          />
          <Person
            color={PINK}
            head={[128, 24]}
            face="l"
            hip={[124, 78]}
            knees={[[110, 126], [146, 126]]}
            feet={[[102, 126], [154, 126]]}
            hands={[[150, 52], [104, 56]]}
            tag="คุกเข่าใส่"
            tagAt={[140, 16]}
          />
        </>
      );
    case "press":
      return (
        <>
          <Bed />
          <Person
            color={GOLD}
            head={[42, 86]}
            face="r"
            hip={[120, 96]}
            knees={[[92, 40], [132, 36]]}
            feet={[[78, 24], [118, 18]]}
            hands={[[70, 100], [58, 110]]}
            tag="พับขา"
            tagAt={[22, 76]}
          />
          <Person
            color={PINK}
            head={[96, 28]}
            face="l"
            hip={[126, 74]}
            knees={[[114, 126], [148, 126]]}
            feet={[[106, 126], [156, 126]]}
            hands={[[88, 50], [70, 62]]}
            tag="กดลง"
            tagAt={[108, 18]}
          />
        </>
      );
    case "sideFace":
      return (
        <>
          <Bed />
          <Person
            color={GOLD}
            head={[58, 52]}
            face="r"
            hip={[70, 96]}
            knees={[[50, 128], [90, 128]]}
            feet={[[40, 128], [100, 128]]}
            hands={[[108, 78], [80, 86]]}
            tag="ตะแคง"
            tagAt={[32, 40]}
          />
          <Person
            color={PINK}
            head={[150, 50]}
            face="l"
            hip={[138, 94]}
            knees={[[118, 128], [158, 128]]}
            feet={[[110, 128], [168, 128]]}
            hands={[[104, 76], [132, 84]]}
            tag="หันเข้าหากัน"
            tagAt={[154, 38]}
          />
        </>
      );
    case "bound":
      return (
        <>
          <Bed />
          <Person
            color={GOLD}
            head={[96, 48]}
            face="r"
            hip={[100, 96]}
            knees={[[88, 126], [114, 126]]}
            feet={[[78, 126], [104, 126]]}
            hands={[[92, 108], [108, 108]]}
            tag="มัดมือ"
            tagAt={[62, 38]}
          />
          <Person
            color={PINK}
            head={[168, 30]}
            face="l"
            hip={[156, 88]}
            knees={[[144, 142], [168, 142]]}
            feet={[[140, 142], [174, 142]]}
            hands={[[118, 70], [148, 64]]}
            tag="คนสั่ง"
            tagAt={[172, 20]}
          />
        </>
      );
    case "spank":
      return (
        <>
          <rect x="16" y="104" width="140" height="16" rx="5" fill={FURN} />
          <Person
            color={GOLD}
            head={[42, 56]}
            face="l"
            hip={[122, 90]}
            knees={[[116, 142], [136, 142]]}
            feet={[[112, 142], [142, 142]]}
            hands={[[38, 104], [54, 104]]}
            tag="ก้ม"
            tagAt={[22, 42]}
          />
          <Person
            color={PINK}
            head={[190, 30]}
            face="l"
            hip={[164, 86]}
            knees={[[154, 142], [178, 142]]}
            feet={[[150, 142], [184, 142]]}
            hands={[[128, 72], [118, 86]]}
            tag="ตบก้น"
            tagAt={[176, 18]}
          />
        </>
      );
    case "blind":
      return (
        <>
          <Bed />
          <Person
            color={GOLD}
            head={[78, 42]}
            face="r"
            hip={[86, 92]}
            knees={[[76, 142], [98, 142]]}
            feet={[[72, 142], [104, 142]]}
            hands={[[118, 78], [74, 86]]}
            tag="ปิดตา"
            tagAt={[48, 30]}
            blindfold
          />
          <Person
            color={PINK}
            head={[150, 34]}
            face="l"
            hip={[142, 90]}
            knees={[[130, 142], [154, 142]]}
            feet={[[126, 142], [160, 142]]}
            hands={[[112, 74], [148, 70]]}
            tag="จูง"
            tagAt={[158, 22]}
          />
        </>
      );
    default:
      return null;
  }
}

export function PoseArt({ pose }: { pose: PoseId }) {
  return (
    <div className="mb-3">
      <svg viewBox="0 0 260 168" className="mx-auto h-44 w-full" aria-hidden>
        <rect width="260" height="168" rx="18" fill="var(--color-elevated)" />
        <Scene pose={pose} />
      </svg>
      <p className="mt-2 text-center text-sm text-champagne">{HINT[pose]}</p>
      <p className="text-center text-xs text-subtle">ตัวทองมีผม = คนรับ · ตัวชมพู = คนนำ · จุดขาวบนหัว = ทิศหน้า</p>
    </div>
  );
}
