import { useEffect, useRef, useState } from "react";
import { DICE_PIP, DICE_TIME, getDiceTables, type DiceFace } from "@/lib/game/mini";
import { fisherYatesShuffle } from "@/lib/game/shuffle";
import { useGameStore } from "@/lib/game/store";
import type { LevelId } from "@/lib/game/types";
import { cn } from "@/lib/utils";

export function DicePlay({ level }: { level: LevelId }) {
  const drink = useGameStore((s) => s.drink);
  const completeCard = useGameStore((s) => s.completeCard);
  const currentPlayerIndex = useGameStore((s) => s.currentPlayerIndex);
  const tables = getDiceTables(level);
  const leftoverPose = useRef<DiceFace[]>([]);
  const leftoverAct = useRef<DiceFace[]>([]);
  const lock = useRef(false);
  const timers = useRef<number[]>([]);
  useEffect(() => {
    const pending = timers.current;
    return () => pending.forEach((id) => window.clearTimeout(id));
  }, []);
  const [rolling, setRolling] = useState(false);
  const [faces, setFaces] = useState<[number, number, number] | null>(null);
  const [preview, setPreview] = useState<[number, number, number]>([5, 5, 5]);
  const [result, setResult] = useState<{ pose: DiceFace; act: DiceFace; time: number } | null>(
    null,
  );

  function take<T>(bag: { current: T[] }, source: T[]): T {
    if (bag.current.length === 0) bag.current = fisherYatesShuffle([...source]);
    return bag.current.shift() ?? source[0]!;
  }

  function roll() {
    if (lock.current) return;
    lock.current = true;
    setRolling(true);
    setFaces(null);
    setResult(null);
    const a = Math.floor(Math.random() * 6);
    const b = Math.floor(Math.random() * 6);
    const c = Math.floor(Math.random() * 6);
    const pose = take(leftoverPose, tables.pose);
    const act = take(leftoverAct, tables.act);
    const time = DICE_TIME[c]!;
    let ticks = 0;
    const timer = window.setInterval(() => {
      ticks += 1;
      setPreview([
        Math.floor(Math.random() * 6),
        Math.floor(Math.random() * 6),
        Math.floor(Math.random() * 6),
      ]);
      if (ticks >= 12) {
        window.clearInterval(timer);
        setPreview([a, b, c]);
        setFaces([a, b, c]);
        setResult({ pose, act, time });
        setRolling(false);
        lock.current = false;
      }
    }, 80);
    timers.current.push(timer);
  }

  const shown = faces ?? preview;
  const pose = result?.pose;
  const act = result?.act;
  const time = result?.time;

  return (
    <section className="glass flex min-h-56 flex-1 flex-col items-center rounded-2xl p-5">
      <p className="text-xs uppercase tracking-wider text-champagne">🎲 ลูกเต๋า 3 ลูก</p>
      <p className="mt-1 text-center text-sm text-muted">
        ทอยท่า · ทอยการกระทำ · ทอยเวลา · กองไม่ซ้ำจนกว่าจะหมด
      </p>
      <div className="mt-5 grid w-full grid-cols-3 gap-2">
        {[
          { title: "ท่า", value: shown[0] },
          { title: "ทำ", value: shown[1] },
          { title: "วินาที", value: shown[2] },
        ].map((die) => (
          <div
            key={die.title}
            className={cn(
              "flex flex-col items-center rounded-xl bg-elevated py-4",
              rolling && "dice-bounce",
            )}
          >
            <span className="text-4xl leading-none">{DICE_PIP[die.value]}</span>
            <span className="mt-2 text-xs text-subtle">{die.title}</span>
          </div>
        ))}
      </div>
      <div className="mt-5 w-full space-y-2 text-center">
        <p className="font-display text-xl leading-snug">
          {pose ? `${pose.emoji} ${pose.label}` : "ทอยแล้วได้ท่า"}
        </p>
        {act && time ? (
          <>
            <p className="text-sm text-muted">
              {act.emoji} {act.label}
            </p>
            <p className="text-sm text-champagne">ทำ {time} วินาที ห้ามคิดมาก</p>
          </>
        ) : null}
      </div>
      <button
        type="button"
        onClick={roll}
        disabled={rolling}
        className="glow-primary mt-5 flex h-12 w-full items-center justify-center rounded-xl bg-primary font-medium text-primary-fg touch-manipulation"
      >
        {rolling ? "กำลังทอย..." : result ? "ทอยใหม่" : "ทอยลูกเต๋า"}
      </button>
      <div className="mt-3 grid w-full grid-cols-2 gap-2">
        <button
          type="button"
          onClick={() => drink(currentPlayerIndex)}
          className="flex h-12 items-center justify-center rounded-xl bg-elevated font-medium"
        >
          🍷 ไม่ไหว ดื่ม
        </button>
        <button
          type="button"
          onClick={() => {
            completeCard();
            setFaces(null);
            setResult(null);
          }}
          className={cn(
            "flex h-12 items-center justify-center rounded-xl font-medium",
            result ? "bg-primary text-primary-fg" : "bg-elevated text-muted",
          )}
        >
          ครบแล้ว
        </button>
      </div>
    </section>
  );
}
