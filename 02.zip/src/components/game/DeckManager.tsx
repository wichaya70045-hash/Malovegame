import { useEffect, useMemo, useRef, useState } from "react";
import { Download, FileUp, RotateCcw, X } from "lucide-react";
import { customDeckSize, getEffectiveCards, hasCustomDeck } from "@/lib/game/content";
import {
  MAX_FILE_BYTES,
  exportCombinedText,
  exportLevelText,
  mergeLevels,
  parseDeckFiles,
  summarize,
  type ParseResult,
} from "@/lib/game/deck-text";
import { useGameStore } from "@/lib/game/store";
import { ALL_LEVELS, LEVELS } from "@/lib/game/types";
import { cn } from "@/lib/utils";

function readText(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result ?? ""));
    reader.onerror = () => reject(reader.error ?? new Error("read failed"));
    reader.readAsText(file, "utf-8");
  });
}

function download(name: string, text: string) {
  const url = URL.createObjectURL(new Blob([text], { type: "text/plain;charset=utf-8" }));
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function DeckManager({ open, onClose }: { open: boolean; onClose: () => void }) {
  const revision = useGameStore((s) => s.deckRevision);
  const applyDeck = useGameStore((s) => s.applyDeck);
  const input = useRef<HTMLInputElement>(null);
  const [pending, setPending] = useState<ParseResult | null>(null);
  const [notice, setNotice] = useState<{ tone: "ok" | "error"; text: string } | null>(null);
  const [confirmReset, setConfirmReset] = useState(false);

  // eslint-disable-next-line react-hooks/exhaustive-deps -- revision is the signal that the deck changed
  const current = useMemo(() => (open ? getEffectiveCards() : []), [open, revision]);
  const custom = open && hasCustomDeck();

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  useEffect(() => {
    if (!open) {
      setPending(null);
      setNotice(null);
      setConfirmReset(false);
    }
  }, [open]);

  if (!open) return null;

  async function onFiles(list: FileList | null) {
    if (!list || list.length === 0) return;
    setNotice(null);
    setPending(null);
    const files: { name: string; text: string }[] = [];
    for (const file of Array.from(list)) {
      if (file.size > MAX_FILE_BYTES) {
        setNotice({
          tone: "error",
          text: `ไฟล์ ${file.name} ใหญ่เกิน ${MAX_FILE_BYTES / 1024 / 1024} MB`,
        });
        return;
      }
      try {
        files.push({ name: file.name, text: await readText(file) });
      } catch {
        setNotice({ tone: "error", text: `อ่านไฟล์ ${file.name} ไม่ได้` });
        return;
      }
    }
    const result = parseDeckFiles(files);
    setPending(result);
    if (result.cards.length === 0) {
      setNotice({ tone: "error", text: "ไม่พบไพ่ที่ใช้ได้ในไฟล์ที่เลือก ตรวจรูปแบบแล้วลองใหม่" });
    }
    if (input.current) input.current.value = "";
  }

  function confirmApply() {
    if (!pending || pending.cards.length === 0) return;
    const merged = mergeLevels(current, pending.cards, pending.levels);
    const ok = applyDeck(merged);
    if (ok) {
      setNotice({
        tone: "ok",
        text: `ใช้ไพ่จากไฟล์แล้ว เลเวล ${pending.levels.join(", ")} (${pending.cards.length} ใบ) กองที่จั่วไว้ถูกสับใหม่`,
      });
      setPending(null);
    } else {
      setNotice({
        tone: "error",
        text: "เก็บไพ่ไม่ได้ พื้นที่เบราว์เซอร์เต็มหรือปิดการเก็บข้อมูล",
      });
    }
  }

  function resetDeck() {
    if (!confirmReset) {
      setConfirmReset(true);
      return;
    }
    applyDeck(null);
    setConfirmReset(false);
    setPending(null);
    setNotice({ tone: "ok", text: "กลับไปใช้ไพ่ต้นฉบับแล้ว" });
  }

  const rows = summarize(current);
  const incoming = pending ? summarize(pending.cards) : [];

  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center sm:items-center">
      <button
        type="button"
        aria-label="ปิด"
        className="absolute inset-0 bg-bg/80"
        onClick={onClose}
      />
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="deck-title"
        className="glass relative z-10 max-h-[88dvh] w-full max-w-md overflow-y-auto rounded-t-2xl p-5 pb-[max(1.25rem,env(safe-area-inset-bottom))] sm:rounded-2xl"
      >
        <div className="mb-4 flex items-center justify-between">
          <h2 id="deck-title" className="font-display text-xl font-semibold">
            จัดการไพ่
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="flex size-11 items-center justify-center rounded-md text-muted hover:text-fg"
            aria-label="ปิดจัดการไพ่"
          >
            <X className="size-5" />
          </button>
        </div>

        <p className="rounded-lg bg-elevated px-3 py-2 text-sm text-muted">
          {custom
            ? `ตอนนี้ใช้ไพ่จากไฟล์ที่นำเข้า (${customDeckSize()} ใบ)`
            : "ตอนนี้ใช้ไพ่ต้นฉบับของเกม"}
        </p>

        <section className="mt-5">
          <h3 className="text-sm font-medium">1 · ดาวน์โหลดไพ่เป็นไฟล์ข้อความ</h3>
          <p className="mt-1 text-xs text-subtle">
            แก้ไขข้อความ คำท้า และเวลา (เช่น [60s]) ในไฟล์ได้เลย แล้วนำกลับมาอัปโหลดในข้อ 2
          </p>
          <button
            type="button"
            onClick={() => download("all-levels.txt", exportCombinedText(current))}
            className="mt-3 flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-elevated font-medium transition-transform duration-150 active:scale-[0.97]"
          >
            <Download className="size-4" />
            ทุกเลเวล (ไฟล์เดียว)
          </button>
          <div className="mt-2 grid grid-cols-3 gap-2">
            {ALL_LEVELS.map((level) => {
              const meta = LEVELS.find((l) => l.id === level);
              return (
                <button
                  key={level}
                  type="button"
                  onClick={() => download(`level-${level}.txt`, exportLevelText(level, current))}
                  className="flex min-h-11 flex-col items-center justify-center rounded-lg bg-elevated px-1 text-xs transition-transform duration-150 active:scale-[0.97]"
                >
                  <span className="font-medium">LV {level === 9 ? "ลับ" : level}</span>
                  <span className="text-subtle">{meta?.name}</span>
                </button>
              );
            })}
          </div>
          {rows.length > 0 ? (
            <ul className="mt-3 space-y-0.5 text-xs text-subtle">
              {rows.map((row) => (
                <li key={row.level} className="flex justify-between tabular-nums">
                  <span>LV {row.level === 9 ? "ลับ" : row.level}</span>
                  <span>
                    {row.total} ใบ · จับเวลา {row.timed}
                  </span>
                </li>
              ))}
            </ul>
          ) : null}
        </section>

        <section className="mt-6">
          <h3 className="text-sm font-medium">2 · อัปโหลดไฟล์ที่แก้แล้ว</h3>
          <p className="mt-1 text-xs text-subtle">
            เลือกได้หลายไฟล์ เลเวลที่อยู่ในไฟล์จะแทนที่เลเวลนั้นทั้งหมด เลเวลอื่นยังเหมือนเดิม
          </p>
          <input
            ref={input}
            type="file"
            accept=".txt,text/plain"
            multiple
            className="sr-only"
            id="deck-file"
            onChange={(e) => void onFiles(e.target.files)}
          />
          <button
            type="button"
            onClick={() => input.current?.click()}
            className="glow-primary mt-3 flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-primary font-medium text-primary-fg transition-transform duration-150 active:scale-[0.97]"
          >
            <FileUp className="size-4" />
            เลือกไฟล์ .txt
          </button>

          {pending && pending.cards.length > 0 ? (
            <div className="mt-3 rounded-xl bg-elevated p-3">
              <p className="text-sm font-medium">พบไพ่ที่ใช้ได้ {pending.cards.length} ใบ</p>
              <ul className="mt-2 space-y-0.5 text-xs text-muted">
                {incoming.map((row) => (
                  <li key={row.level} className="flex justify-between tabular-nums">
                    <span>LV {row.level === 9 ? "ลับ" : row.level}</span>
                    <span>
                      {row.total} ใบ · จับเวลา {row.timed} · BDSM {row.bdsm}
                    </span>
                  </li>
                ))}
              </ul>
              {pending.skipped > 0 ? (
                <p className="mt-2 text-xs text-champagne">
                  ข้าม {pending.skipped} บรรทัดที่มีปัญหา (ดูด้านล่าง)
                </p>
              ) : null}
              <div className="mt-3 grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setPending(null)}
                  className="flex h-11 items-center justify-center rounded-lg bg-surface text-sm"
                >
                  ยกเลิก
                </button>
                <button
                  type="button"
                  onClick={confirmApply}
                  className="flex h-11 items-center justify-center rounded-lg bg-primary text-sm font-medium text-primary-fg"
                >
                  ใช้ไพ่ชุดนี้
                </button>
              </div>
            </div>
          ) : null}

          {pending && (pending.errors.length > 0 || pending.warnings.length > 0) ? (
            <div className="mt-3 max-h-40 overflow-y-auto rounded-xl bg-surface p-3 text-xs">
              {pending.errors.slice(0, 12).map((issue, i) => (
                <p key={`e${i}`} className="text-primary">
                  ✕ {issue.file} บรรทัด {issue.line}: {issue.message}
                </p>
              ))}
              {pending.errors.length > 12 ? (
                <p className="text-primary">… และอีก {pending.errors.length - 12} ข้อผิดพลาด</p>
              ) : null}
              {pending.warnings.slice(0, 8).map((issue, i) => (
                <p key={`w${i}`} className="text-champagne">
                  ! {issue.file}
                  {issue.line ? ` บรรทัด ${issue.line}` : ""}: {issue.message}
                </p>
              ))}
              {pending.warnings.length > 8 ? (
                <p className="text-champagne">… และอีก {pending.warnings.length - 8} คำเตือน</p>
              ) : null}
            </div>
          ) : null}
        </section>

        {notice ? (
          <p
            role="status"
            className={cn(
              "mt-4 rounded-lg px-3 py-2 text-sm",
              notice.tone === "ok"
                ? "bg-champagne/15 text-champagne"
                : "bg-primary/15 text-primary",
            )}
          >
            {notice.text}
          </p>
        ) : null}

        {custom ? (
          <button
            type="button"
            onClick={resetDeck}
            className={cn(
              "mt-5 flex h-12 w-full items-center justify-center gap-2 rounded-xl text-sm font-medium",
              confirmReset ? "bg-wine text-fg" : "bg-elevated text-muted",
            )}
          >
            <RotateCcw className="size-4" />
            {confirmReset ? "กดอีกครั้งเพื่อยืนยัน" : "กลับไปใช้ไพ่ต้นฉบับ"}
          </button>
        ) : null}
      </div>
    </div>
  );
}
