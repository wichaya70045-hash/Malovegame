import { useEffect, useRef, useState } from "react";
import { getChaosPool, type ChaosRule } from "@/lib/game/chaos";
import { fisherYatesShuffle } from "@/lib/game/shuffle";
import { fillNames } from "@/lib/game/content";
import { useGameStore } from "@/lib/game/store";
import type { LevelId } from "@/lib/game/types";
import { cn } from "@/lib/utils";

const MAX_STACK = 3;

export function ChaosPlay({ level }: { level: LevelId }) {
  const players = useGameStore((s) => s.players);
  const currentPlayerIndex = useGameStore((s) => s.currentPlayerIndex);
  const drink = useGameStore((s) => s.drink);
  const completeCard = useGameStore((s) => s.completeCard);
  const bdsmOn = useGameStore((s) => s.bdsmOn);
  const me = players[currentPlayerIndex]!;
  const you = players[currentPlayerIndex === 0 ? 1 : 0]!;
  const leftover = useRef<ChaosRule[]>([]);
  const lock = useRef(false);
  const timers = useRef<number[]>([]);
  useEffect(() => {
    const pending = timers.current;
    return () => pending.forEach((id) => window.clearTimeout(id));
  }, []);
  const [stack, setStack] = useState<ChaosRule[]>([]);
  const [flash, setFlash] = useState<ChaosRule | null>(null);

  function refill() {
    leftover.current = fisherYatesShuffle(getChaosPool(level, bdsmOn));
  }

  function draw() {
    if (lock.current) return;
    if (stack.length >= MAX_STACK) return;
    lock.current = true;
    if (leftover.current.length === 0) refill();
    const next = leftover.current.shift();
    if (!next) {
      lock.current = false;
      return;
    }
    setFlash(next);
    const settle = window.setTimeout(() => {
      setStack((cur) => [...cur, next].slice(-MAX_STACK));
      setFlash(null);
      lock.current = false;
    }, 280);
    timers.current.push(settle);
  }

  function drop(index: number) {
    setStack((cur) => cur.filter((_, i) => i !== index));
    completeCard();
  }

  function miss() {
    drink(currentPlayerIndex);
  }

  const say = (text: string) => fillNames(text, me.name, you.name);

  return (
    <section className="glass flex min-h-56 flex-1 flex-col rounded-2xl p-5">
      <p className="text-center text-xs uppercase tracking-wider text-champagne">🌀 กฎค้าง</p>
      <p className="mt-1 text-center text-sm text-muted">
        จั่วกฎแปลกติดตัวได้ถึง {MAX_STACK} ข้อ ผิดกฎ = ดื่ม ทิ้งได้เมื่อทำครบ
      </p>

      {flash ? (
        <div className="card-in mt-4 rounded-xl bg-primary/20 px-4 py-5 text-center">
          <p className="text-3xl">{flash.emoji}</p>
          <p className="mt-2 font-display text-lg leading-snug">{say(flash.text)}</p>
        </div>
      ) : stack.length === 0 ? (
        <button
          type="button"
          onClick={draw}
          className="pulse-glow glow-primary mt-4 flex min-h-40 flex-1 flex-col items-center justify-center rounded-xl bg-elevated"
        >
          <span className="text-4xl">🌀</span>
          <span className="mt-3 font-display text-2xl">จั่วกฎแปลก</span>
          <span className="mt-1 text-sm text-muted">กฎจะติดตัวจนกว่าจะทิ้ง</span>
        </button>
      ) : (
        <div className="mt-4 space-y-2">
          {stack.map((rule, index) => (
            <div key={`${rule.text}-${index}`} className="rounded-xl bg-elevated px-3 py-3">
              <p className="font-display text-base leading-snug">
                <span className="mr-2">{rule.emoji}</span>
                {say(rule.text)}
              </p>
              <button
                type="button"
                onClick={() => drop(index)}
                className="mt-2 text-xs font-medium text-primary"
              >
                ทิ้งกฎนี้ · ครบแล้ว
              </button>
            </div>
          ))}
        </div>
      )}

      <div className="mt-4 grid grid-cols-2 gap-2">
        <button
          type="button"
          onClick={miss}
          className="flex h-12 items-center justify-center rounded-xl bg-elevated font-medium"
        >
          🍷 ผิดกฎ ดื่ม
        </button>
        <button
          type="button"
          onClick={draw}
          disabled={stack.length >= MAX_STACK || Boolean(flash)}
          className={cn(
            "flex h-12 items-center justify-center rounded-xl font-medium",
            stack.length >= MAX_STACK ? "bg-elevated text-muted" : "bg-primary text-primary-fg",
          )}
        >
          {stack.length >= MAX_STACK ? "เต็ม 3 ข้อ" : "จั่วซ้อน"}
        </button>
      </div>
      {stack.length > 0 ? (
        <button
          type="button"
          onClick={() => {
            setStack([]);
            completeCard();
          }}
          className="mt-2 flex h-11 items-center justify-center rounded-xl bg-elevated text-sm text-muted"
        >
          ล้างกฎทั้งหมด
        </button>
      ) : null}
    </section>
  );
}
