import { useEffect, useRef, useState } from "react";
import { REEL_PLACE, reelPose, reelRole, type ReelItem } from "@/lib/game/mini";
import { useGameStore } from "@/lib/game/store";
import type { LevelId } from "@/lib/game/types";
import { CardTimer } from "./CardTimer";
import { cn } from "@/lib/utils";

function Reel({
  items,
  index,
  spinning,
  label,
}: {
  items: ReelItem[];
  index: number;
  spinning: boolean;
  label: string;
}) {
  const item = items[index % items.length]!;
  return (
    <div className="flex flex-1 flex-col items-center">
      <p className="mb-2 text-xs text-subtle">{label}</p>
      <div className="flex h-28 w-full flex-col items-center justify-center overflow-hidden rounded-xl bg-elevated">
        <span className={cn("text-4xl", spinning && "reel-spin")}>{item.emoji}</span>
        <span className="mt-2 px-1 text-center text-sm font-medium leading-tight">
          {item.label}
        </span>
      </div>
    </div>
  );
}

export function TripleWheel({ level }: { level: LevelId }) {
  const drink = useGameStore((s) => s.drink);
  const completeCard = useGameStore((s) => s.completeCard);
  const currentPlayerIndex = useGameStore((s) => s.currentPlayerIndex);
  const poses = reelPose(level);
  const roles = reelRole(level);
  const lock = useRef(false);
  const timers = useRef<number[]>([]);
  useEffect(() => {
    const pending = timers.current;
    return () => pending.forEach((id) => window.clearTimeout(id));
  }, []);
  const [spinning, setSpinning] = useState(false);
  const [idx, setIdx] = useState<[number, number, number]>([0, 0, 0]);
  const [locked, setLocked] = useState(false);
  const [spinId, setSpinId] = useState(0);

  function spin() {
    if (lock.current) return;
    lock.current = true;
    setSpinning(true);
    setLocked(false);
    const next: [number, number, number] = [
      Math.floor(Math.random() * REEL_PLACE.length),
      Math.floor(Math.random() * poses.length),
      Math.floor(Math.random() * roles.length),
    ];
    const t1 = window.setTimeout(() => setIdx([next[0], idx[1], idx[2]]), 500);
    const t2 = window.setTimeout(() => setIdx([next[0], next[1], idx[2]]), 900);
    const t3 = window.setTimeout(() => {
      setIdx(next);
      setSpinning(false);
      setLocked(true);
      setSpinId((n) => n + 1);
      lock.current = false;
    }, 1400);
    timers.current.push(t1, t2, t3);
  }

  const place = REEL_PLACE[idx[0] % REEL_PLACE.length]!;
  const pose = poses[idx[1] % poses.length]!;
  const role = roles[idx[2] % roles.length]!;

  return (
    <section className="glass flex min-h-56 flex-1 flex-col rounded-2xl p-5">
      <p className="text-center text-xs uppercase tracking-wider text-champagne">
        🎯 ที่ · ท่า · บท
      </p>
      <p className="mt-1 text-center text-sm text-muted">ปั่นสามวง แล้วเล่นฉากนั้น 4 นาที</p>
      <div className="mt-4 flex gap-2">
        <Reel items={REEL_PLACE} index={idx[0]} spinning={spinning} label="ที่" />
        <Reel items={poses} index={idx[1]} spinning={spinning} label="ท่า" />
        <Reel items={roles} index={idx[2]} spinning={spinning} label="บท" />
      </div>
      <p className="mt-5 min-h-14 text-center font-display text-lg leading-snug">
        {spinning
          ? "กำลังปั่น..."
          : locked
            ? `${place.emoji} ${place.label} · ${pose.emoji} ${pose.label} · ${role.emoji} ${role.label}`
            : "กดปั่นแล้วเข้าฉากเลย"}
      </p>
      {locked && !spinning ? (
        <div className="mt-2">
          <CardTimer seconds={240} cardId={`triple-${spinId}`} />
        </div>
      ) : null}
      <button
        type="button"
        onClick={spin}
        disabled={spinning}
        className="glow-primary mt-4 flex h-12 w-full items-center justify-center rounded-xl bg-primary font-medium text-primary-fg"
      >
        {spinning ? "..." : locked ? "ปั่นใหม่" : "ปั่นทั้งสามวง"}
      </button>
      <div className="mt-3 grid grid-cols-2 gap-2">
        <button
          type="button"
          onClick={() => drink(currentPlayerIndex)}
          className="flex h-12 items-center justify-center rounded-xl bg-elevated font-medium"
        >
          🍷 ไม่ครบ ดื่ม
        </button>
        <button
          type="button"
          onClick={() => {
            completeCard();
            setLocked(false);
          }}
          className={cn(
            "flex h-12 items-center justify-center rounded-xl font-medium",
            locked ? "bg-primary text-primary-fg" : "bg-elevated text-muted",
          )}
        >
          ครบฉาก
        </button>
      </div>
    </section>
  );
}
