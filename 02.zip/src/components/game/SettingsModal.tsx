import { useEffect, useState } from "react";
import { FileText, X } from "lucide-react";
import { LEVELS } from "@/lib/game/types";
import { useGameStore } from "@/lib/game/store";
import { cn } from "@/lib/utils";
import { DeckManager } from "./DeckManager";

export function SettingsModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const thresholds = useGameStore((s) => s.unlockThresholds);
  const setThreshold = useGameStore((s) => s.setThreshold);
  const bdsmOn = useGameStore((s) => s.bdsmOn);
  const setBdsmOn = useGameStore((s) => s.setBdsmOn);
  const [deckOpen, setDeckOpen] = useState(false);

  useEffect(() => {
    if (!open || deckOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, deckOpen, onClose]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center">
      <button
        type="button"
        aria-label="ปิด"
        className="absolute inset-0 bg-bg/70"
        onClick={onClose}
      />
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="settings-title"
        className="glass relative z-10 max-h-[80dvh] w-full max-w-md overflow-y-auto rounded-t-2xl p-6 sm:rounded-2xl"
      >
        <div className="mb-5 flex items-center justify-between">
          <h2 id="settings-title" className="font-display text-xl font-semibold">
            ตั้งค่าปลดล็อค
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="flex size-11 items-center justify-center rounded-md text-muted transition-transform duration-150 ease-out hover:text-fg active:scale-[0.96]"
            aria-label="ปิดตั้งค่า"
          >
            <X className="size-5" />
          </button>
        </div>
        <button
          type="button"
          onClick={() => setBdsmOn(!bdsmOn)}
          className={cn(
            "mb-5 flex min-h-12 w-full items-center justify-between rounded-xl px-4 text-left",
            bdsmOn ? "bg-primary/20 ring-1 ring-primary" : "bg-elevated",
          )}
        >
          <span>
            <span className="block text-sm font-medium">BDSM ในทุกโหมด</span>
            <span className="block text-xs text-muted">มัด ปิดตา สั่ง ตบ — มีคำหยุด</span>
          </span>
          <span
            className={cn(
              "relative h-6 w-11 shrink-0 rounded-full",
              bdsmOn ? "bg-primary" : "bg-subtle",
            )}
          >
            <span
              className={cn(
                "absolute top-0.5 size-5 rounded-full bg-fg",
                bdsmOn ? "translate-x-5" : "translate-x-0.5",
              )}
            />
          </span>
        </button>
        <button
          type="button"
          onClick={() => setDeckOpen(true)}
          className="mb-5 flex min-h-12 w-full items-center gap-3 rounded-xl bg-elevated px-4 text-left transition-transform duration-150 active:scale-[0.97]"
        >
          <FileText className="size-5 shrink-0 text-champagne" />
          <span>
            <span className="block text-sm font-medium">จัดการไพ่ (นำเข้า / ส่งออกไฟล์)</span>
            <span className="block text-xs text-muted">
              ดาวน์โหลดเป็น .txt แก้คำถาม คำท้า เวลา แล้วอัปโหลดกลับ
            </span>
          </span>
        </button>
        <p className="mb-4 text-sm text-muted">
          เลเวล 2–8 และระดับลับ ปลดเมื่อแก้วรวมถึงเลขที่ตั้ง
        </p>
        <ul className="space-y-3">
          {LEVELS.slice(1).map((level, i) => (
            <li
              key={level.id}
              className="flex items-center justify-between gap-3 rounded-lg bg-elevated px-3 py-2"
            >
              <div>
                <p className="text-sm font-medium">
                  LV {level.id === 9 ? "ลับ" : level.id} {level.name}
                </p>
                <p className="text-xs text-subtle">{level.tagline}</p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  className="flex size-11 items-center justify-center rounded-md bg-surface text-lg text-fg transition-transform duration-150 ease-out active:scale-[0.96]"
                  onClick={() => setThreshold(i, (thresholds[i] ?? 1) - 1)}
                  aria-label={`ลดเกณฑ์เลเวล ${level.id}`}
                >
                  −
                </button>
                <span className="w-8 text-center font-medium tabular-nums">
                  {thresholds[i] ?? 0}
                </span>
                <button
                  type="button"
                  className="flex size-11 items-center justify-center rounded-md bg-surface text-lg text-fg transition-transform duration-150 ease-out active:scale-[0.96]"
                  onClick={() => setThreshold(i, (thresholds[i] ?? 1) + 1)}
                  aria-label={`เพิ่มเกณฑ์เลเวล ${level.id}`}
                >
                  +
                </button>
              </div>
            </li>
          ))}
        </ul>
        <button
          type="button"
          onClick={onClose}
          className={cn(
            "mt-5 flex h-12 w-full items-center justify-center rounded-lg bg-primary font-medium text-primary-fg",
            "transition-transform duration-150 ease-out active:scale-[0.96]",
          )}
        >
          บันทึก
        </button>
      </div>
      <DeckManager open={deckOpen} onClose={() => setDeckOpen(false)} />
    </div>
  );
}
