import { useEffect, useMemo, useRef, useState } from "react";
import { makePowerDeck, powerCommands, type PowerKind } from "@/lib/game/mini";
import { fisherYatesShuffle } from "@/lib/game/shuffle";
import { useGameStore } from "@/lib/game/store";
import type { LevelId } from "@/lib/game/types";
import { cn } from "@/lib/utils";

const TOTAL_ROUNDS = 7;

export function PowerPlay({ level }: { level: LevelId }) {
  const players = useGameStore((s) => s.players);
  const drink = useGameStore((s) => s.drink);
  const completeCard = useGameStore((s) => s.completeCard);
  const commands = powerCommands(level);
  const leftover = useRef<PowerKind[]>(fisherYatesShuffle(makePowerDeck()));
  const lock = useRef(false);
  const timers = useRef<number[]>([]);
  useEffect(() => {
    const pending = timers.current;
    return () => pending.forEach((id) => window.clearTimeout(id));
  }, []);
  const [round, setRound] = useState(1);
  const [flipped, setFlipped] = useState(false);
  const [pair, setPair] = useState<[PowerKind, PowerKind] | null>(null);
  const [picked, setPicked] = useState<string | null>(null);

  const result = useMemo(() => {
    if (!pair) return null;
    if (pair[0] === pair[1]) return "tie";
    return pair[0] === "master" ? 0 : 1;
  }, [pair]);

  function drawPair(): [PowerKind, PowerKind] {
    if (leftover.current.length < 2) leftover.current = fisherYatesShuffle(makePowerDeck());
    const a = leftover.current.shift() ?? "master";
    const b = leftover.current.shift() ?? "servant";
    return [a, b];
  }

  function draw() {
    if (lock.current) return;
    lock.current = true;
    setFlipped(false);
    setPicked(null);
    const next = drawPair();
    setPair(next);
    const flip = window.setTimeout(() => {
      setFlipped(true);
      lock.current = false;
    }, 280);
    timers.current.push(flip);
  }

  function nextRound() {
    completeCard();
    if (round >= TOTAL_ROUNDS) {
      leftover.current = fisherYatesShuffle(makePowerDeck());
      setRound(1);
    } else {
      setRound((n) => n + 1);
    }
    setPair(null);
    setFlipped(false);
    setPicked(null);
  }

  return (
    <section className="glass flex min-h-56 flex-1 flex-col rounded-2xl p-5">
      <p className="text-center text-xs uppercase tracking-wider text-champagne">👑 สลับอำนาจ</p>
      <p className="mt-1 text-center text-sm text-muted">
        จั่วคนละใบ · นายสั่งได้ · รอบ {round}/{TOTAL_ROUNDS}
        {round === TOTAL_ROUNDS ? " · รอบสุดท้ายสั่งได้ยาว" : ""}
      </p>
      <div className="mt-4 grid grid-cols-2 gap-3">
        {players.map((player, i) => {
          const kind = pair?.[i as 0 | 1];
          const isMaster = kind === "master";
          return (
            <div key={i} className="flex flex-col items-center">
              <p className="mb-2 text-xs text-subtle">{player.name}</p>
              <button
                type="button"
                onClick={pair ? undefined : draw}
                className="power-card h-36 w-full"
              >
                <div className={cn("power-card-inner", flipped && pair && "is-flipped")}>
                  <div className="power-face power-back">🎴</div>
                  <div
                    className={cn(
                      "power-face power-front",
                      isMaster ? "text-champagne" : "text-muted",
                    )}
                  >
                    <span className="text-4xl">{isMaster ? "👑" : "🙇"}</span>
                    <span className="mt-2 text-sm font-medium">{isMaster ? "นาย" : "ตาม"}</span>
                  </div>
                </div>
              </button>
            </div>
          );
        })}
      </div>

      {!pair ? (
        <button
          type="button"
          onClick={draw}
          className="glow-primary mt-5 flex h-12 w-full items-center justify-center rounded-xl bg-primary font-medium text-primary-fg"
        >
          จั่วไพ่ทั้งคู่
        </button>
      ) : !flipped ? (
        <p className="mt-5 text-center text-sm text-muted">กำลังพลิก...</p>
      ) : result === "tie" ? (
        <div className="mt-5 text-center">
          <p className="font-display text-lg">เสมอกัน 🍷</p>
          <p className="mt-1 text-sm text-muted">ทั้งคู่ดื่ม แล้วจั่วใหม่</p>
          <button
            type="button"
            onClick={() => {
              drink(0);
              drink(1);
              draw();
            }}
            className="mt-4 flex h-12 w-full items-center justify-center rounded-xl bg-primary font-medium text-primary-fg"
          >
            ดื่มแล้วจั่วใหม่
          </button>
        </div>
      ) : (
        <div className="mt-5">
          <p className="text-center font-display text-lg">👑 {players[result!]?.name} เป็นนาย</p>
          <p className="mt-1 text-center text-sm text-muted">เลือกคำสั่ง หรือสั่งเองก็ได้</p>
          <div className="mt-3 grid gap-2">
            {commands.map((cmd) => (
              <button
                key={cmd.text}
                type="button"
                onClick={() => setPicked(cmd.text)}
                className={cn(
                  "min-h-11 rounded-lg px-3 py-2 text-left text-sm",
                  picked === cmd.text ? "bg-primary text-primary-fg" : "bg-elevated",
                )}
              >
                {cmd.emoji} {cmd.text}
              </button>
            ))}
          </div>
          <div className="mt-3 grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => drink(result === 0 ? 1 : 0)}
              className="flex h-12 items-center justify-center rounded-xl bg-elevated font-medium"
            >
              🍷 ตามไม่ไหว
            </button>
            <button
              type="button"
              onClick={nextRound}
              className="flex h-12 items-center justify-center rounded-xl bg-primary font-medium text-primary-fg"
            >
              {round >= TOTAL_ROUNDS ? "จบเซต" : "รอบถัดไป"}
            </button>
          </div>
        </div>
      )}
    </section>
  );
}
