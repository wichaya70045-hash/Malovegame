//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DmOIAEyt.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/tmp/g/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CP4WF8uF.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CP4WF8uF.js"
		} }]
	},
	"/": {
		filePath: "/tmp/g/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-TDkHa6Qu.js"]
	}
} });
//#endregion
export { tsrStartManifest };
